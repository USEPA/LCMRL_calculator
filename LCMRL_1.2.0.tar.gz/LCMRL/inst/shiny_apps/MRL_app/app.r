library(shiny)
library(LCMRL)

# Detect OS type once and store it in a global variable
os_type <- .Platform$OS.type

# Define default file handle for TestData
defaultFH <- system.file("extdata", "MRLTest-small.csv", package = "LCMRL")

# Create a new environment for QC variables
qc_env <- new.env()

# Initialize QC variables in the environment
qc_env$BadUnitsWarning <- 0

# Define the UI
ui <- fluidPage(
  tags$head(
    tags$style(HTML("
      #messages {
        white-space: pre-wrap;
        overflow-y: auto;
        max-height: 300px;
        font-size: 0.9em; /* Scale font size proportionally */
      }
      .logo-container {
        margin-top: 10px; /* Add space above the logo */
      }
      /* Base font size */
      body, h3, .btn, .form-control, .shiny-input-container {
        font-size: 16px; /* Reduced base font size */
      }
      /* Responsive font size adjustments */
      @media (max-width: 1200px) {
        body, h3, .btn, .form-control, .shiny-input-container {
          font-size: 14px; /* Reduced font size for medium screens */
        }
        #messages {
          font-size: 0.8em; /* Scale messages font size proportionally */
        }
      }
      @media (max-width: 768px) {
        body, h3, .btn, .form-control, .shiny-input-container {
          font-size: 12px; /* Reduced font size for smaller screens */
        }
        #messages {
          font-size: 0.7em; /* Scale messages font size proportionally */
        }
      }
    "))
  ),
  fluidRow(
    column(2, tags$div(class = "logo-container", tags$img(src = "logo.png", height = "75px")))
  ),
  sidebarLayout(
    sidebarPanel(
      tags$h3("MRL Calculator", style = "font-size: 14pt;"),
      actionButton("set_directory_btn", "Set Working Directory"),
      br(), br(),
      conditionalPanel(
        condition = "output.directorySet == true",
        actionButton("validate_btn", "Validate Installation"),
        br(), br(),
        actionButton("get_test_data_btn", "Get Test Data"),
        br(), br(),
        fileInput("csv_file", "Load Lab Data CSV:", accept = ".csv"),
        br(),
        actionButton("advanced_options_btn", "Advanced Options"),
        uiOutput("process_ui")
      ),
      br(), br(),
      # Conditional panel for the restore messages button
      conditionalPanel(
        condition = "output.showMessages == false",
        actionButton("restore_messages_btn", "Restore Messages")
      ),
      actionButton("exit_btn", "Exit")
    ),
    mainPanel(
      conditionalPanel(
        condition = "output.showMessages == true",
        tags$div(
          style = "border: 1px solid #ccc; padding: 10px; background-color: #f9f9f9; margin-top: 10px;",
          verbatimTextOutput("messages"),
          uiOutput("warning_image_ui"),
          actionButton("hide_messages_btn", "Hide Messages")
        )
      )
    )
  )
)

server <- function(input, output, session) {
  # Initialize params as a reactiveValues object
  params <- reactiveValues(
    custom = list(
      rnnr = FALSE,
      biter = FALSE,
      Seed = FALSE,
      Abbr = FALSE,
      Threads = FALSE
    ),
    rnnr = 0,
    biter = 200,
    Seed = "0261948",
    Abbr = TRUE,
    Threads = parallel::detectCores() - 1
  )
  
  file_path <- reactiveVal(defaultFH)
  working_directory <- reactiveVal(getwd())
  directorySet <- reactiveVal(FALSE)
  
  # Set default working directory
  project_root <- dirname(dirname(dirname(dirname(dirname(getwd())))))  # Navigate up five levels
  default_working_dir <- file.path(project_root, "Working Directory")
  if (!dir.exists(default_working_dir)) {
    dir.create(default_working_dir, recursive = TRUE)
  }
  setwd(default_working_dir)
  working_directory <- reactiveVal(default_working_dir)
  dataLoaded <- reactiveVal(FALSE)
  
  # Initialize messages with a welcome message
  showMessages <- reactiveVal(TRUE)
  messages <- reactiveVal(
    paste(
      "Welcome to the US EPA MRL Calculator\n",
      "Let's begin by setting a working directory\n",
      sep = ""
    )
  )
  
  original_filename <- reactiveVal("")
  
  # Reactive to check if the current message contains "Warning"
  isWarning <- reactive({
    any(grepl("Warning", messages(), ignore.case = TRUE))
  })
  
  # Reactive to check if the current message indicates successful data load
  isSuccessfulLoad <- reactive({
    any(grepl("RNNR", messages(), ignore.case = TRUE)) && !isWarning()
  })
  
  # Output to control the visibility of other buttons
  output$directorySet <- reactive({
    directorySet()
  })
  outputOptions(output, "directorySet", suspendWhenHidden = FALSE)
  
  output$showMessages <- reactive({
    showMessages()
  })
  outputOptions(output, "showMessages", suspendWhenHidden = FALSE)
  
  # Render the messages with line breaks
  output$messages <- renderText({
    paste(messages(), collapse = "")
  })
  
  # Render the warning image conditionally
  output$warning_image_ui <- renderUI({
    if (isWarning()) {
      tags$img(src = "warning.png", height = "75px", style = "margin-bottom: 10px;")
    } else if (isSuccessfulLoad()) {
      tags$img(src = "check.png", height = "75px", style = "margin-bottom: 10px;")
    } else {
      NULL
    }
  })
  
  # Timer setup
  timer <- reactiveVal(Sys.time())
  timer_active <- reactiveVal(TRUE)  # Flag to control timer activity
  
  # Observe inactivity timer
  observe({
    invalidateLater(1000, session)
    if (timer_active() && difftime(Sys.time(), timer(), units = "secs") > 28) {
      showModal(modalDialog(
        title = "Session Timeout",
        "Session timed out due to inactivity. Please close this tab and try again.",
        easyClose = TRUE,
        footer = NULL
      ))
      
      # Delay the closure of the R session to allow the message to be displayed
      Sys.sleep(0.5)  # Delay for half a second
      
      # Close the R session
      stopApp()
    }
  })
  
  # Function to reset inactivity timer
  resetInactivityTimer <- function() {
    timer(Sys.time())
  }
  
  # Reset timer on any user interaction except "Hide Messages"
  observeEvent(input$set_directory_btn, {
    resetInactivityTimer()
    timer_active(FALSE)  # Disable the timer after setting the directory
    folder <- tryCatch({
      choose.dir(default = getwd(), caption = "Select Working Directory")
    }, error = function(e) {
      getwd()  
    })
    
    if (!is.null(folder) && folder != "") {
      working_directory(folder)
      setwd(folder)
      directorySet(TRUE)
      messages(paste("Working directory set to:\n", folder, "\n"))
      showMessages(TRUE)
    } else {
      messages("No directory selected or directory path is invalid.\n")
      showMessages(TRUE)
    }
  })
  
  observeEvent(input$get_test_data_btn, {
    resetInactivityTimer()
    messages("Copying MRL test data...\n")
    tryCatch({
      GetTestDataMRL()  # Use the new function for MRL test data
      messages("MRL Test Data copied successfully.\n")
      showMessages(TRUE)
    }, error = function(e) {
      messages(paste0("Error copying MRL test data: ", e$message, "\n"))
      showMessages(TRUE)
    })
  })
  
  observeEvent(input$csv_file, {
    resetInactivityTimer()
    req(input$csv_file)
    original_filename(tools::file_path_sans_ext(basename(input$csv_file$name)))
    messages("Loading user data...\n")
    tryCatch({
      file_path(input$csv_file$datapath)
      original_filename(tools::file_path_sans_ext(basename(input$csv_file$name)))
      messages("Data loaded successfully.\n")
      GetData(input$csv_file$datapath)  # Load data into fh.labdata
      
      messages(get_log_buffer())
      clear_log_buffer()
      showMessages(TRUE)
    }, error = function(e) {
      messages(paste0("Error loading file: ", e$message, "\n"))
      showMessages(TRUE)
    })
  })
  
  observeEvent(input$validate_btn, {
    resetInactivityTimer()
    withProgress(message = 'Validating Installation...', value = 0, {
      tryCatch({
        result <- MRL.Summary(
          fh.labdata = file_path(), 
          original_filename = original_filename(), 
          biter = params$biter, 
          Seed = params$Seed, 
          abbr.out = params$Abbr, 
          rnnr = params$rnnr, 
          Threads = params$Threads
        )
        incProgress(1)
        
        # Retrieve and display log messages
        log_messages <- get_log_buffer()
        messages(paste(log_messages, collapse = "\n"))
        clear_log_buffer()
        showMessages(TRUE)
        
        # Display timing information for each analyte
        timing_info <- result[[2]]
        timing_messages <- sapply(names(timing_info), function(analyte) {
          time_data <- timing_info[[analyte]]
          paste("Analyte:", analyte, "- Time to do", params$biter, "iterations per Lab using", params$Threads, "threads:",
                time_data$minutes, "minutes", time_data$seconds, "seconds")
        })
        
        # Append timing messages to the existing messages
        messages(paste(messages(), paste(timing_messages, collapse = "\n"), sep = "\n"))
        showMessages(TRUE)
        
        # Open the working directory if needed
        if (os_type == "windows") {
          shell.exec(normalizePath(working_directory()))
        } else if (os_type == "unix") {
          if (Sys.info()["sysname"] == "Darwin") {
            system(paste("open", normalizePath(working_directory())))
          } else {
            system(paste("xdg-open", normalizePath(working_directory())))
          }
        }
      }, error = function(e) {
        messages(paste0("Error during validation: ", e$message, "\n"))
        showMessages(TRUE)
      })
    })
  })
  
  output$process_ui <- renderUI({
    if (!is.null(file_path())) {
      actionButton("process_btn", "Process MRL")
    }
  })
  
  observeEvent(input$process_btn, {
    resetInactivityTimer()
    withProgress(message = 'Processing MRL...', value = 0, {
      tryCatch({
        result <- MRL.Summary(
          fh.labdata = file_path(), 
          original_filename = original_filename(), 
          biter = params$biter, 
          Seed = params$Seed, 
          abbr.out = params$Abbr, 
          rnnr = params$rnnr, 
          Threads = params$Threads
        )
        incProgress(1)
        
        # Retrieve and display log messages
        log_messages <- get_log_buffer()
        messages(paste(log_messages, collapse = "\n"))
        clear_log_buffer()
        showMessages(TRUE)
        
        # Display timing information for each analyte
        timing_info <- result[[2]]
        total_seconds <- 0
        timing_messages <- sapply(names(timing_info), function(analyte) {
          time_data <- timing_info[[analyte]]
          total_seconds <<- total_seconds + (time_data$minutes * 60 + time_data$seconds)
          paste("Analyte:", analyte, "- Time to do", params$biter, "iterations per Lab using", params$Threads, "threads:",
                time_data$minutes, "minutes", time_data$seconds, "seconds")
        })
        
        # Calculate total time in minutes and seconds
        total_minutes <- total_seconds %/% 60
        total_seconds <- total_seconds %% 60
        total_time_message <- paste("Total calculation time for all analytes:", total_minutes, "minutes", total_seconds, "seconds")
        
        # Append timing messages and total time to the existing messages
        messages(paste(messages(), paste(timing_messages, collapse = "\n"), total_time_message, sep = "\n"))
        showMessages(TRUE)
        
        # Open the working directory if needed
        if (os_type == "windows") {
          shell.exec(normalizePath(working_directory()))
        } else if (os_type == "unix") {
          if (Sys.info()["sysname"] == "Darwin") {
            system(paste("open", normalizePath(working_directory())))
          } else {
            system(paste("xdg-open", normalizePath(working_directory())))
          }
        }
      }, error = function(e) {
        messages(paste0("Error during processing: ", e$message, "\n"))
        showMessages(TRUE)
      })
    })
  })
  
  observeEvent(input$hide_messages_btn, {
    # Do not reset the inactivity timer here
    showMessages(FALSE)
  })
  
  # Observer for the restore messages button
  observeEvent(input$restore_messages_btn, {
    showMessages(TRUE)
  })
  
  observeEvent(input$advanced_options_btn, {
    resetInactivityTimer()
    showModal(modalDialog(
      title = "Advanced Options",
      checkboxInput("custom_rnnr", "Enable custom RNNR", value = params$custom$rnnr),
      conditionalPanel(
        condition = "input.custom_rnnr == true",
        numericInput("rnnr_value", "RNNR (0 or 1):", value = params$rnnr, min = 0, max = 1, step = 1)
      ),
      checkboxInput("custom_biter", "Enable custom Biter", value = params$custom$biter),
      conditionalPanel(
        condition = "input.custom_biter == true",
        numericInput("biter_value", "Biter (1 to 999):", value = params$biter, min = 1, max = 999, step = 1)
      ),
      checkboxInput("custom_Seed", "Enable custom Seed", value = params$custom$Seed),
      conditionalPanel(
        condition = "input.custom_Seed == true",
        textInput("Seed_value", "Seed (0000000 to 9999999):", value = params$Seed)
      ),
      checkboxInput("custom_Abbr", "Enable custom Abbr", value = params$custom$Abbr),
      conditionalPanel(condition = "input.custom_Abbr == true",
                       selectInput("Abbr_value", "Abbr:", choices = c("TRUE", "FALSE"), selected = as.character(params$Abbr))
      ),
      checkboxInput("custom_Threads", "Enable custom Threads", value = params$custom$Threads),
      conditionalPanel(
        condition = "input.custom_Threads == true",
        numericInput("Threads_value", "Threads (1 to 256):", value = params$Threads, min = 1, max = 256, step = 1)
      ),
      footer = tagList(
        modalButton("Cancel"),
        actionButton("apply_advanced_options", "Apply")
      )
    ))
  })
  
  observeEvent(input$apply_advanced_options, {
    resetInactivityTimer()
    removeModal()
    
    params$custom$rnnr <- isTRUE(input$custom_rnnr)
    params$custom$biter <- isTRUE(input$custom_biter)
    params$custom$Seed <- isTRUE(input$custom_Seed)
    params$custom$Abbr <- isTRUE(input$custom_Abbr)
    params$custom$Threads <- isTRUE(input$custom$Threads)
    
    if (params$custom$rnnr) params$rnnr <- input$rnnr_value
    if (params$custom$biter) params$biter <- input$biter_value
    if (params$custom$Seed) params$Seed <- input$Seed_value
    if (params$custom$Abbr) params$Abbr <- as.logical(input$Abbr_value)
    if (params$custom$Threads) params$Threads <- input$Threads_value
    
    messages("Advanced options applied.\n")
    showMessages(TRUE)
  })
  
  observeEvent(input$exit_btn, {
    showModal(modalDialog(
      title = "Exit Confirmation",
      "Your R session has ended. Please close this tab to exit the application.",
      easyClose = FALSE,
      footer = NULL
    ))
    
    # Delay the closure of the R session to allow the message to be displayed
    Sys.sleep(0.5)  # Delay for half a second
    
    # Close the R session
    stopApp()
  })
}

# Run the application
shinyApp(ui, server)