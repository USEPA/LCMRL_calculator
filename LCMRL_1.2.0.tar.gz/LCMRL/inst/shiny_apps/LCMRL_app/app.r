library(shiny)
library(LCMRL)

# Detect OS type once and store it in a global variable
os_type <- .Platform$OS.type

# Define default file handle for TestData
defaultFH <- system.file("extdata", "LCMRLTestData.csv", package = "LCMRL")

# Create a new environment for QC variables
qc_env <- new.env()

# Initialize QC variables in the environment
qc_env$BadUnitsWarning <- 0

# Define the UI
ui <- fluidPage(
  tags$head(
    tags$style(HTML("
      #messages {
        white-space: pre-wrap;
        overflow-y: auto;
        max-height: 300px;
        font-size: 0.9em; /* Scale font size proportionally */
      }
      .logo-container {
        margin-top: 10px; /* Add space above the logo */
      }
      /* Base font size */
      body, h3, .btn, .form-control, .shiny-input-container {
        font-size: 16px; /* Reduced base font size */
      }
      /* Responsive font size adjustments */
      @media (max-width: 1200px) {
        body, h3, .btn, .form-control, .shiny-input-container {
          font-size: 14px; /* Reduced font size for medium screens */
        }
        #messages {
          font-size: 0.8em; /* Scale messages font size proportionally */
        }
      }
      @media (max-width: 768px) {
        body, h3, .btn, .form-control, .shiny-input-container {
          font-size: 12px; /* Reduced font size for smaller screens */
        }
        #messages {
          font-size: 0.7em; /* Scale messages font size proportionally */
        }
      }
    "))
  ),
  fluidRow(
    column(2, tags$div(class = "logo-container", tags$img(src = "logo.png", height = "75px")))
  ),
  sidebarLayout(
    sidebarPanel(
      tags$h3("LCMRL Calculator", style = "font-size: 14pt;"),
      actionButton("set_directory_btn", "Set Working Directory"),
      br(), br(),
      conditionalPanel(
        condition = "output.directorySet == true",
        actionButton("validate_btn", "Validate Installation"),
        br(), br(),
        actionButton("get_test_data_btn", "Get Test Data"),
        br(), br(),
        fileInput("csv_file", "Load Lab Data CSV:", accept = ".csv"),
        br(),
        actionButton("advanced_options_btn", "Advanced Options"),
        uiOutput("process_ui")
      ),
      br(), br(),
      # Conditional panel for the restore messages button
      conditionalPanel(
        condition = "output.showMessages == false",
        actionButton("restore_messages_btn", "Restore Messages")
      ),
      actionButton("exit_btn", "Exit")
    ),
    mainPanel(
      conditionalPanel(
        condition = "output.showMessages == true",
        tags$div(
          style = "border: 1px solid #ccc; padding: 10px; background-color: #f9f9f9; margin-top: 10px;",
          verbatimTextOutput("messages"),
          uiOutput("warning_image_ui"),
          actionButton("hide_messages_btn", "Hide Messages")
        )
      )
    )
  )
)

server <- function(input, output, session) {
  # Initialize params as a reactiveValues object
  params <- reactiveValues(
    custom = list(
      LQL = FALSE,
      UQL = FALSE,
      CPR = FALSE,
      alph = FALSE,
      bet = FALSE,
      rnnr = FALSE
    ),
    LQL = 0.5,
    UQL = 1.5,
    CPR = 0.99,
    alph = 0.05,
    bet = 0.05,
    rnnr = 1
  )
  
  file_path <- reactiveVal(defaultFH)
  working_directory <- reactiveVal(getwd())
  directorySet <- reactiveVal(FALSE)
  
  # Set default working directory
  project_root <- dirname(dirname(dirname(dirname(dirname(getwd())))))  # Navigate up five levels
  default_working_dir <- file.path(project_root, "Working Directory")
  if (!dir.exists(default_working_dir)) {
    dir.create(default_working_dir, recursive = TRUE)
  }
  setwd(default_working_dir)
  working_directory <- reactiveVal(default_working_dir)
  dataLoaded <- reactiveVal(FALSE)
  
  # Initialize messages with a welcome message
  showMessages <- reactiveVal(TRUE)
  messages <- reactiveVal(
    paste(
      "Welcome to the US EPA LCMRL Calculator\n",
      "Let's begin by setting a working directory\n",
      sep = ""
    )
  )
  
  original_filename <- reactiveVal("")
  
  # Reactive to check if the current message contains "Warning"
  isWarning <- reactive({
    any(grepl("Warning", messages(), ignore.case = TRUE))
  })
  
  # Reactive to check if the current message indicates successful data load
  isSuccessfulLoad <- reactive({
    any(grepl("RNNR", messages(), ignore.case = TRUE)) && !isWarning()
  })
  
  # Output to control the visibility of other buttons
  output$directorySet <- reactive({
    directorySet()
  })
  outputOptions(output, "directorySet", suspendWhenHidden = FALSE)
  
  output$showMessages <- reactive({
    showMessages()
  })
  outputOptions(output, "showMessages", suspendWhenHidden = FALSE)
  
  # Render the messages with line breaks
  output$messages <- renderText({
    paste(messages(), collapse = "")
  })
  
  # Render the warning image conditionally
  output$warning_image_ui <- renderUI({
    if (isWarning()) {
      tags$img(src = "warning.png", height = "75px", style = "margin-bottom: 10px;")
    } else if (isSuccessfulLoad()) {
      tags$img(src = "check.png", height = "75px", style = "margin-bottom: 10px;")
    } else {
      NULL
    }
  })
  
  # Timer setup
  timer <- reactiveVal(Sys.time())
  timer_active <- reactiveVal(TRUE)  # Flag to control timer activity
  
  # Observe inactivity timer
  observe({
    invalidateLater(1000, session)
    if (timer_active() && difftime(Sys.time(), timer(), units = "secs") > 28) {
      showModal(modalDialog(
        title = "Session Timeout",
        "Session timed out due to inactivity. Please close this tab and try again.",
        easyClose = TRUE,
        footer = NULL
      ))
      
      # Delay the closure of the R session to allow the message to be displayed
      Sys.sleep(0.5)  # Delay for half a second
      
      # Close the R session
      stopApp()
    }
  })
  
  # Function to reset inactivity timer
  resetInactivityTimer <- function() {
    timer(Sys.time())
  }
  
  # Reset timer on any user interaction except "Hide Messages"
  observeEvent(input$set_directory_btn, {
    resetInactivityTimer()
    timer_active(FALSE)  # Disable the timer after setting the directory
    folder <- tryCatch({
      choose.dir(default = getwd(), caption = "Select Working Directory")
    }, error = function(e) {
      getwd()  
    })
    
    if (!is.null(folder) && folder != "") {
      working_directory(folder)
      setwd(folder)
      directorySet(TRUE)
      messages(paste("Working directory set to:\n", folder, "\n"))
      showMessages(TRUE)
    } else {
      messages("No directory selected or directory path is invalid.\n")
      showMessages(TRUE)
    }
  })
  
  observeEvent(input$get_test_data_btn, {
    resetInactivityTimer()
    messages("Copying test data...\n")
    tryCatch({
      GetTestData()
      messages("Test data copied successfully.\n")
      showMessages(TRUE)
    }, error = function(e) {
      messages(paste0("Error copying test data: ", e$message, "\n"))
      showMessages(TRUE)
    })
  })
  
  observeEvent(input$csv_file, {
    resetInactivityTimer()
    req(input$csv_file)
    messages("Loading user data...\n")
    tryCatch({
      file_path(input$csv_file$datapath)
      original_filename(tools::file_path_sans_ext(basename(input$csv_file$name)))
      messages("Data loaded successfully.\n")
      GetData(fh = input$csv_file$datapath)
      
      messages(get_log_buffer())
      clear_log_buffer()
      showMessages(TRUE)
      
      # Set dataLoaded to TRUE to enable further processing
      dataLoaded(TRUE)
      
    }, error = function(e) {
      messages(paste0("Error loading file: ", e$message, "\n"))
      showMessages(TRUE)
    })
  })
  
  observeEvent(input$validate_btn, {
    resetInactivityTimer()
    withProgress(message = 'Validating Installation...', value = 0, {
      tryCatch({
        # Load test data for validation
        GetData(Validate_LCMRL = TRUE)
        
        # Process values using test data
        LCMRL.Values(fh.labdata, working_directory = working_directory(), Validate_LCMRL = TRUE)
        incProgress(0.5)
        
        # Generate graphs using test data
        LCMRL.Graphs(fh.labdata, working_directory = working_directory(), Validate_LCMRL = TRUE)
        incProgress(1)
        
        # Log messages and show feedback
        messages(get_log_buffer())
        clear_log_buffer()
        showMessages(TRUE)
        
        messages("Validation complete.\n")
        showMessages(TRUE)
        
        # Open the working directory in the system's file explorer
        if (os_type == "windows") {
          shell.exec(normalizePath(working_directory()))
        } else if (.Platform$OS.type == "unix") {
          if (Sys.info()["sysname"] == "Darwin") {
            system(paste("open", normalizePath(working_directory())))
          } else {
            system(paste("xdg-open", normalizePath(working_directory())))
          }
        }
      }, error = function(e) {
        messages(paste0("Error during validation: ", e$message, "\n"))
        showMessages(TRUE)
      })
    })
  })
  
  output$process_ui <- renderUI({
    if (!is.null(file_path())) {
      actionButton("process_btn", "Process LCMRL")
    }
  })
  
  observeEvent(input$process_btn, {
    resetInactivityTimer()
    withProgress(message = 'Processing LCMRL...', value = 0, {
      tryCatch({
        values_args <- list(fh = file_path(), outfh = file.path(working_directory(), paste0(original_filename(), "-LCMRL-Values.csv")))
        graphs_args <- list(fh = file_path(), outfh = file.path(working_directory(), paste0(original_filename(), "-LCMRL-Graphs.pdf")))
        
        # Add custom parameters if set
        if (params$custom$LQL) values_args$LQL <- params$LQL
        if (params$custom$UQL) values_args$UQL <- params$UQL
        if (params$custom$CPR) values_args$CPR <- params$CPR
        if (params$custom$alph) values_args$alph <- params$alph
        if (params$custom$bet) values_args$bet <- params$bet
        if (params$custom$rnnr) values_args$rnnr <- params$rnnr
        
        if (params$custom$UQL) graphs_args$UQL <- params$UQL
        if (params$custom$CPR) graphs_args$CPR <- params$CPR
        if (params$custom$alph) graphs_args$alph <- params$alph
        if (params$custom$bet) graphs_args$bet <- params$bet
        if (params$custom$rnnr) graphs_args$rnnr <- params$rnnr
        
        process_results <- do.call(LCMRL.Values, values_args)
        incProgress(0.5)
        graph_results <- do.call(LCMRL.Graphs, graphs_args)
        incProgress(1)
        
        messages(get_log_buffer())
        clear_log_buffer()
        showMessages(TRUE)
        
        messages("Processing complete.\n")
        showMessages(TRUE)
        
        if (os_type == "windows") {
          shell.exec(normalizePath(working_directory()))
        } else if (.Platform$OS.type == "unix") {
          if (Sys.info()["sysname"] == "Darwin") {
            system(paste("open", normalizePath(working_directory())))
          } else {
            system(paste("xdg-open", normalizePath(working_directory())))
          }
        }
      }, error = function(e) {
        messages(paste0("Error during processing: ", e$message, "\n"))
        showMessages(TRUE)
      })
    })
  })
  
  observeEvent(input$hide_messages_btn, {
    # Do not reset the inactivity timer here
    showMessages(FALSE)
  })
  
  # Observer for the restore messages button
  observeEvent(input$restore_messages_btn, {
    showMessages(TRUE)
  })
  
  observeEvent(input$advanced_options_btn, {
    resetInactivityTimer()
    showModal(modalDialog(
      title = "Advanced Options",
      checkboxInput("custom_LQL", "Enable custom LQL", value = params$custom$LQL),
      conditionalPanel(
        condition = "input.custom_LQL == true",
        numericInput("LQL_value", "LQL (0 to 1):", value = params$LQL, min = 0, max = 1, step = 0.1)
      ),
      checkboxInput("custom_UQL", "Enable custom UQL", value = params$custom$UQL),
      conditionalPanel(
        condition = "input.custom_UQL == true",
        numericInput("UQL_value", "UQL (1 to 2):", value = params$UQL, min = 1, max = 2, step = 0.1)
      ),
      checkboxInput("custom_CPR", "Enable custom CPR", value = params$custom$CPR),
      conditionalPanel(
        condition = "input.custom_CPR == true",
        numericInput("CPR_value", "CPR (0 to 1):", value = params$CPR, min = 0, max = 1, step = 0.01)
      ),
      checkboxInput("custom_alph", "Enable custom Alpha", value = params$custom$alph),
      conditionalPanel(
        condition = "input.custom_alph == true",
        numericInput("alph_value", "Alpha (0 to 1):", value = params$alph, min = 0, max = 1, step = 0.01)
      ),
      checkboxInput("custom_bet", "Enable custom Beta", value = params$custom$bet),
      conditionalPanel(
        condition = "input.custom_bet == true",
        numericInput("bet_value", "Beta (0 to 1):", value = params$bet, min = 0, max = 1, step = 0.01)
      ),
      checkboxInput("custom_rnnr", "Enable custom RNNR", value = params$custom$rnnr),
      conditionalPanel(
        condition = "input.custom_rnnr == true",
        numericInput("rnnr_value", "RNNR (0 or 1):", value = params$rnnr, min = 0, max = 1, step = 1)
      ),
      footer = tagList(
        modalButton("Cancel"),
        actionButton("apply_advanced_options", "Apply")
      )
    ))
  })
  
  observeEvent(input$apply_advanced_options, {
    resetInactivityTimer()
    removeModal()
    
    params$custom$LQL <- isTRUE(input$custom_LQL)
    params$custom$UQL <- isTRUE(input$custom_UQL)
    params$custom$CPR <- isTRUE(input$custom_CPR)
    params$custom$alph <- isTRUE(input$custom_alph)
    params$custom$bet <- isTRUE(input$custom_bet)
    params$custom$rnnr <- isTRUE(input$custom_rnnr)
    
    if (params$custom$LQL) params$LQL <- input$LQL_value
    if (params$custom$UQL) params$UQL <- input$UQL_value
    if (params$custom$CPR) params$CPR <- input$CPR_value
    if (params$custom$alph) params$alph <- input$alph_value
    if (params$custom$bet) params$bet <- input$bet_value
    if (params$custom$rnnr) params$rnnr <- input$rnnr_value
    
    messages("Advanced options applied.\n")
    showMessages(TRUE)
  })
  
  observeEvent(input$exit_btn, {
    showModal(modalDialog(
      title = "Exit Confirmation",
      "Your R session has ended. Please close this tab to exit the application.",
      easyClose = FALSE,
      footer = NULL
    ))
    
    Sys.sleep(0.5)  # Delay for half a second
    stopApp()
  })
}

# Run the application
shinyApp(ui, server)