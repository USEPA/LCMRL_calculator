#  ASG Edits 6-9-2025
#  Nov 11 2009
#
# MRL LCMRL Estimation R Scripts
#
#####################################################################
# ---------------------Libraries Needed -----------------------------
library(car)           # needed for MRL.Output  
library(lattice)       # needed for densityplot() in MRL.Stats      
library(doParallel)    # needed for BB.MRL
library(foreach)       # needed for BB.MRL

# --------------------- End Libraries Needed ------------------------
#####################################################################
# Set global default fh for TestData
defaultFH <- system.file("extdata", "LCMRLTestData.csv", package = "LCMRL")
defaultFHMRL <- system.file("extdata", "MRLTest-small.csv", package = "LCMRL")

# -------------------Global Log Buffer-------------------------------

# Create a new environment for logging
log_env <- new.env()

# Initialize the log buffer in the environment
log_env$log_buffer <- character()

#' Append messages to the log buffer
#' @export
append_to_log <- function(message) {
  log_env$log_buffer <- c(log_env$log_buffer, message)
}

#' Retrieve the log buffer
#' @export
get_log_buffer <- function() {
  return(log_env$log_buffer)
}

#' Clear the log buffer
#' @export
clear_log_buffer <- function() {
  log_env$log_buffer <- character()
}

# -------------------Utility Functions To Access TestData---------------------
#' Shows the file location of the TestData in the LCMRL R package
#' @export
ShowTestData <- function() {
  defaultFH <- system.file("extdata", "LCMRLTestData.csv", package = "LCMRL")
  print('The TestData for the LCMRL calculator is found here:')
  print(defaultFH)
}

#' Copies the TestData to a user specified folder and opens the directory
#' @export
GetTestData <- function() {
  defaultFH <- system.file("extdata", "LCMRLTestData.csv", package = "LCMRL")
  targetPath <- SelectDirOS()
  
  if (file.copy(defaultFH, targetPath, overwrite = TRUE)) {  # Add overwrite = TRUE
    print(paste('File copied to:', targetPath))
    
    # Open the directory where the file was copied
    if (.Platform$OS.type == "windows") {
      shell.exec(normalizePath(targetPath))
    } else if (.Platform$OS.type == "unix") {
      if (Sys.info()["sysname"] == "Darwin") {
        system(paste("open", shQuote(targetPath)))  # macOS
      } else {
        system(paste("xdg-open", shQuote(targetPath)))  # Linux
      }
    }
  } else {
    print("Error: File could not be copied.")
  }
}
#' Copies the MRL Test Data to a user specified folder and opens the directory
#' @export
GetTestDataMRL <- function() {
  defaultFHMRL <- system.file("extdata", "MRLTest-small.csv", package = "LCMRL")
  targetPath <- SelectDirOS()
  
  if (file.copy(defaultFHMRL, targetPath, overwrite = TRUE)) {
    print(paste('MRL Test Data copied to:', targetPath))
    
    # Open the directory where the file was copied
    if (.Platform$OS.type == "windows") {
      shell.exec(normalizePath(targetPath))
    } else if (.Platform$OS.type == "unix") {
      if (Sys.info()["sysname"] == "Darwin") {
        system(paste("open", shQuote(targetPath)))  # macOS
      } else {
        system(paste("xdg-open", shQuote(targetPath)))  # Linux
      }
    }
  } else {
    print("Error: MRL Test Data could not be copied.")
  }
}
# -------------------Set Global QC Variables---------------------

# Create a new environment for QC variables
qc_env <- new.env()

# Initialize QC variables in the environment
qc_env$IsTestData <- 0
qc_env$MixedDataSet <- 0
qc_env$BadUnitsWarning <- 0
qc_env$RatioWarning <- 0

## --------------------------------------------------------------------------------
## Select Directory using platform specific functions
#' @export
SelectDirOS <- function() {
  if (.Platform$OS.type == "windows") {
    filepath <- choose.dir(default = getwd(), caption = "Save TestData to...")
  } else if (.Platform$OS.type == "unix") {
    filepath <- getwd()  # Default to current working directory for Unix systems
  }
  
  # Verify the filepath and handle errors
  if (is.null(filepath) || filepath == "") {
    stop("Error: No directory selected or invalid path.")
  } else {
    print(paste("Selected directory:", filepath))
  }
  
  return(filepath)
}

####################################################################
# ---------------------start MRL.Summary ---------------------------------
#  ASG 5/30/25 - Configured to take rnnr value from GetData with fallback for Test Data
#' Generate MRL Summary for Multi-Lab LCMRL data
# fh.labdata = filehandle (name) with multi-laboratory data in csv format
#          header :
#           COLUMN 1: Analyte Name
#           COLUMN 2: Laboratory Name
#           COLUMN 3: Spiking Level
#           Column 4: Laboratory Measure at Spiking Level
#           Column 5: (Optional) Measurement Units. Default = "ug/L"
#' @param fh.labdata Path/Filename of the .CSV file containing multi-lab replicate data, Must specify
#' @param rnnr flag for Required Non-Negative Response
#' @param biter number of desired bootstrap iterations. Default = 200
#' @param Seed Random seed starting value for Bayesian Weights for consistency of results, Default = "0261948". This allows results to be repeated.
#' @param abbr.out logical flag for type of output data for MRL summary, TRUE is default, False for extended Output which includes un-weighted table summaries
#' @export
MRL.Summary <- function(fh.labdata = defaultFHMRL, original_filename, biter = 200, Seed = 0261948, abbr.out = TRUE, rnnr = 1, Threads = NULL) {
  
  # ----------------Outputs------------------------------------
  #  via MRL.Stats
  #   =  a character matrix or NULL object.
  #            If a matrix:
  #              Column 1: Laboratory Name
  #              Column 2: LCMRL Calculation
  #                          numerical value if it exists else NA
  #              Column 3: LCMRL Result Flag 1, -1 or NA
  #                          1 = Valid LCMRL
  #                         -1 = LCMRL < lowest Non-Zero Spiking Level
  #                         NA = Non-Valid LCMRL or LCMRL cannot be computed
  #            Length of BB.tmp is:
  #               number of labs with Valid LCMRL for original data * boot.iter
  #            Returns NULL if no Labs have a valid LCMRL for orginal data or
  #            inputs are in error.
  #  5 or more files are also output if at least 1 Lab has a valid LCMRL for original
  #          data:
  #
  #  "fh".Rdata.filehandles = filehandles of R adata files with saved objects
  #              and pdf graph objects
  #  MRL.Tables."fh" = .csv file with Tables summarizing the Bayesian Bootstrap
  #             with filename: "Analyte Name".MRL.Tables.csv
  #  "analyte.name".RData = R adata file by simulated MRL data
  #  "fh".LCMRL.Graphs.pdf = pdf files of LCRML graphs
  #  "fh".DensityPlots.pdf = pdf files for density plots of simulated LCMRL values
  
  # ----------------Inputs-------------------------------------
  #
  # fh.labdata = filehandle (name) with multi-laboratory data in csv format
  #        header :
  #           COLUMN 1: Analyte Name
  #           COLUMN 2: Laboratory Name
  #           COLUMN 3: Spiking Level
  #           Column 4: Laboratory Measure at Spiking Level
  #           Column 5: (Optional) Measurement Units. Default = "ug/L"
  # boot.iter = number of desired bootstrap iterations. Default boot.iter= 200
  # rnnr = flag for Required Non-Negative Response
  #        1 is for Required Non-Negative Response
  #        0 is for Negative Response Allowed
  # Seed = Random seed starting value for Bayesian weights for consistency of results
  #        Default value set to "0261948". This allows results to be repeated.
  # abbr.out = logical flag for type of output data for MRL summary
  #            TRUE is default
  #            False for extended Output which includes un-weighted table summaries
  
  # Define default file handle for TestData
  defaultFHMRL <-   defaultFHMRL <- system.file("extdata", "MRLTest-small.csv", package = "LCMRL")
  
  if(fh.labdata == defaultFHMRL) {
    file.copy(defaultFHMRL, getwd(), overwrite = TRUE)
    fh.labdata <- paste(getwd(), "/MRLTest-small.csv", sep = '')
    original_filename <- "MRLTest-small"      
    rnnr <- 1
    MixedDataSet <- 0
    BadUnitsWarning <- 0
    warning("Warning: If you ran this test accidentally, you need to run GetData() again for proper data processing")
  }
  # Estimate MRL Summary Stats & Output Files
  result <- MRL.Stats(fh.labdata, original_filename, rnnr, biter, Seed, Abbr = abbr.out, Threads = Threads)
  
  # Extract timing information
  timing_info <- result[[2]]
  
  # Return timing information along with processing result
  return(list(result[[1]], timing_info))
  
  # Estimate MRL Summary Stats & Output Files
  # MRL.Stats(fh.labdata, original_filename, rnnr, biter, Seed, Abbr = abbr.out, Threads = Threads)
  
  
  # Set up density plots of Bootstrapped LCMRL Estimates by Labs, All Labs & Predicted Lab
  # infile <- paste(strtrim(fh.labdata, nchar(fh.labdata) - 4), ".Rdata.filehandles.csv", sep = '')
  # outfile <- paste(strtrim(fh.labdata, nchar(fh.labdata) - 4), ".DensityPlots.pdf", sep = "")
  # fh <- read.csv(infile, as.is = TRUE)[,1]
  # numfh <- length(fh)
  # holder <- NULL
  # pdf(outfile, paper = "letter")
  # for(i in 1:numfh) {
  #   load(as.character(fh[i]))
  #   show(tmp.den)
  # }
  # dev.off()
}
# --------------------- End MRL Summary------------------------
###############################################################


#####################################################################
# ---------------------start GetData ---------------------------------
# ASG 5/30/25 - Updated 7/1/25 for Shiny compatibility - 8/6 
#' Load and Validate User Data
#'
#' This function loads data from a CSV file and performs checks to ensure data quality,
#' logging relevant warnings and errors for any issues detected.
#'
#' @param fh Optional path to a CSV file. If NULL, file.choose() will prompt the user (interactive only).
#' 
#' @param Validate_LCMRL If TRUE, the LCMRL test data is loaded and interactive file loading is bypassed.
#' 
#' @param Validate_MRL If TRUE, the MRL test data is loaded and interactive file loading is bypassed.
#' 
#' @return None. The function sets global variables for data validation and logs warnings if necessary.
#' 
#' @export

GetData <- function(fh = NULL, rnnr = 1, Validate_LCMRL = FALSE, Validate_MRL = FALSE) {
  # Reset QC Variables at the start
  qc_env$IsTestData <- 0
  qc_env$MixedDataSet <- 0
  qc_env$BadUnitsWarning <- 0
  qc_env$RatioWarning <- 0
  
  # Determine the file path based on validation parameters
  if (Validate_LCMRL) {
    fh <- system.file("extdata", "LCMRLTestData.csv", package = "LCMRL")
    append_to_log("Loading LCMRL test data for validation...\n")
  } else if (Validate_MRL) {
    fh <- system.file("extdata", "MRLTest-small.csv", package = "LCMRL")
    append_to_log("Loading MRL test data for validation...\n")
  } else {
    # Normal file loading routine
    if (is.null(fh)) {
      if (interactive()) {
        append_to_log("No file path provided, prompting user...\n")
        fh <- file.choose()
      } else {
        stop("Error: No file path provided.\n")
      }
    }
  }
  
  fh.labdata <<- fh
  
  # Load and process the data
  data <- try(read.csv(fh), silent = TRUE)
  if (inherits(data, "try-error")) {
    append_to_log("Error: Unable to read CSV file.\n")
    return(NULL)
  }
  
  if (!"Analyte" %in% colnames(data) || !"Lab" %in% colnames(data)) {
    append_to_log("Error: The CSV file must contain 'Analyte' and 'Lab' columns.\n")
    return(NULL)
  }
  
  numeric_data <- data[sapply(data, is.numeric)]
  if (any(numeric_data < 0, na.rm = TRUE)) {
    rnnr <<- 0
  } else {
    rnnr <<- 1
  }
  
  analyte_lab <- paste(data$Analyte, data$Lab, sep = "_")
  unique_analyte_lab <- unique(analyte_lab)
  num_unique_analyte_lab <<- length(unique_analyte_lab)
  
  analyte_lab_with_negatives <- unique(analyte_lab[apply(numeric_data, 1, function(row) any(row < 0, na.rm = TRUE))])
  num_analyte_lab_with_negatives <<- length(analyte_lab_with_negatives)
  
  if ("Spike" %in% colnames(data) && "Result" %in% colnames(data)) {
    if (any((abs(data$Spike) > 1000 | (abs(data$Spike) < 0.000001 & data$Spike != 0)), na.rm = TRUE) || 
        any((abs(data$Result) > 1000 | (abs(data$Result) < 0.000001 & data$Result != 0)), na.rm = TRUE)) {
      qc_env$BadUnitsWarning <- 1
      append_to_log("Warning: Your data set contains values outside of the acceptable range of 1E-6 to 999.\n")
    }
  }
  
  append_to_log(paste("RNNR Value Set To:", rnnr, "\n"))
  append_to_log(paste("Number of unique analytes:", num_unique_analyte_lab, "\n"))
  append_to_log(paste("Number of analytes with negative values:", num_analyte_lab_with_negatives, "\n"))
  
  if (num_analyte_lab_with_negatives > 0 &&
      num_analyte_lab_with_negatives != num_unique_analyte_lab) {
    
    warning_msg <- paste(
      "Warning: The number of analytes with negative values does not match the total number of unique analytes.\n",
      "Mixing positive only analytes with ones with negative values in the same data file will invalidate your results.\n",
      "Note: Entries for the same analyte across multiple labs are considered unique.\n",
      sep = ""
    )
    
    append_to_log(warning_msg)
    qc_env$MixedDataSet <- 1
  }
  print(paste("Setting MixedDataSet:", qc_env$MixedDataSet))
  print(paste("Setting BadUnitsWarning:", qc_env$BadUnitsWarning))  
  invisible(data)
}

# --------------------- End GetData ------------------------
#########################################################################################################################################

#########################################################################################################################################
# ---------------------start LCMRL.Values ---------------------------------
#DIS added for dist 6/16/2020 - ASG 5/30/25 Configured to take rnnr value from GetData with fallback for Test Data - 6-9-2025 Added ratio of highest spiking level to calculated LCMRL assessment
#' Calculate LCMRL Values and generate .CSV summary output for all analytes (LCMRL, DL, Critical Level)
#'
#' @param fh Path/Filename of the .CSV file containing replicate data, Default = TestData
#' @param LQL lower quality limit in LCMRL specification  Default=0.5
#' @param UQL upper quality limit in LCMRL specification   Default =1.5
#' @param CPR quality interval coverage probability requirement in LCMRL specification  Default = 0.99
#' @param alph probability defining critical response (yc) in HV DL  Default = 0.05
#' @param bet = probability defining DL in HV DL: Pr(y <= yc | x = DL),  Default =0.05
#' @param rnnr Is instrument data non-negative? (1=Y, 0=N) Default = 1
#' @param outfh Output file handle, optional
#' @param working_directory The working directory set by the GUI, optional for command line use
#' 
#' @return None. Outputs a CSV file with calculated LCMRL values.
#' 
#' @export
LCMRL.Values <- function(fh = defaultFH, working_directory = NULL, LQL = 0.5, UQL = 1.5, CPR = 0.99, alph = 0.05, bet = 0.05, rnnr = 1, outfh = NULL, Validate_LCMRL = FALSE) {
  # Initialize flags
  #qc_env$MixedDataSet <- 0
  #qc_env$BadUnitsWarning <- 0
  #qc_env$RatioWarning <- 0
  
  # Check if using test data
  if (identical(fh, defaultFH) && !Validate_LCMRL) {
    qc_env$IsTestData <- 1
    fh <- system.file("extdata", "LCMRLTestData.csv", package = "LCMRL")
    outfh <- paste(working_directory, '/TestData-LCMRL.Values.csv', sep = '')  # Use working_directory
    rnnr <- 1
    append_to_log("Using default reference data for LCMRL.Values.\n")
  } else if (is.null(outfh)) {
    fh.a <- strtrim(fh, nchar(fh) - 4)
    outfh <- paste(working_directory, paste0(basename(fh.a), "-LCMRL.Values.csv"), sep = "/")
  }
  
  print(paste("Output file path:", outfh))  # Debugging statement
  
  # Read the data
  dat <- try(read.csv(fh, as.is = TRUE), silent = TRUE)
  if (inherits(dat, "try-error")) {
    append_to_log("Error reading data file.\n")
    stop("Error reading data file.")
  }
  if (ncol(dat) < 6) {
    append_to_log("Error: Number of input fields is less than 6. Check input file for missing fields.\n")
    stop("Error: Number of input fields is less than 6.")
  }
  if (ncol(dat) > 6) {
    append_to_log("Error: Number of input fields is greater than 6. Check input file for extra fields.\n")
    stop("Error: Number of input fields is greater than 6.")
  }
  
  # Extract unique analyte-lab pairs
  ANLab <- paste(dat[, 1], dat[, 2], sep = "--")
  uniq.ANLab <- unique(ANLab)
  num.ANLab <- length(uniq.ANLab)
  
  # Initialize vectors for output
  Anal <- vector("character", num.ANLab)
  Mess <- DLMess <- Anal
  LCMRL <- vector("numeric", num.ANLab)
  RF <- DL <- Lc <- Ratio <- LCMRL
  HighestSpikeRatio <- vector("numeric", num.ANLab)
  Units <- vector("character", num.ANLab)  # New vector for units
  
  # Process each unique analyte-lab pair
  for (kk in 1:num.ANLab) {
    # Filter data for the current analyte-lab pair
    subtt <- dat[ANLab == uniq.ANLab[kk], ]
    
    S <- subtt[, 3]
    M <- subtt[, 4]
    AN.t <- subtt[1, 1]
    U <- try(subtt[1, 6], silent = TRUE)
    if (class(U) == "try-error") {
      U <- NA  # Set to NA if units are not available
    }
    
    # Calculate LCMRL
    tmp <- RobLCMRL(S, M, AN.t, U, lowQL = LQL, upQL = UQL, CovProbReq = CPR, alpha = alph, beta = bet, ReqNonNegResponse = rnnr, grphs = 0, labnum = NULL)
    Anal[kk] <- uniq.ANLab[kk]
    LCMRL[kk] <- tmp[[1]]
    DL[kk] <- tmp[[2]]
    Lc[kk] <- tmp[[3]]
    Ratio[kk] <- tmp[[3]] / tmp[[2]]
    RF[kk] <- tmp[[4]]
    Mess[kk] <- tmp[[5]]
    DLMess[kk] <- tmp[[7]]
    Units[kk] <- U  # Store units
    
    # Calculate the highest spiking level ratio
    highest_spike <- max(S)
    HighestSpikeRatio[kk] <- ifelse(LCMRL[kk] > 0, highest_spike / LCMRL[kk], NA)
    
    # Check if the ratio exceeds 20 and set the warning flag
    if (!is.na(HighestSpikeRatio[kk]) && HighestSpikeRatio[kk] > 20) {
      qc_env$RatioWarning <- 1
      append_to_log("Warning: One or more analytes have a highest spiking level over 20 fold greater than the LCMRL.\n")
    }
  }  # Closing bracket for the `for` loop
  
  # Create the output table
  Table <- data.frame(Anal, LCMRL, DL, Lc, Units, Ratio, HighestSpikeRatio, RF, Mess, DLMess)
  # Define column names for the output table
  dimnames(Table)[[2]] <- c("Analyte", "LCMRL", "DL", "Lc", "Units", "LCMRL/DL", "HighestSpike/LCMRL", "ResultFlag", "Message", "DLMessage")
  
  # Iterate over the rows to update the LCMRL, DL, and DLMessage values for clarity
  # If LCMRL or DL is 0, set them to NA for clarity, and update DLMessage
  for (i in 1:nrow(Table)) {
    if (Table$LCMRL[i] == 0) {
      Table$LCMRL[i] <- NA  # Set LCMRL to NA
    }
    if (Table$DL[i] == 0) {
      Table$DL[i] <- NA  # Set DL to NA
      Table$DLMessage[i] <- "DL Not Calculated"  # Update DLMessage
    }
  }
  
  # Write the output table to a CSV file
  write.csv(Table, outfh, row.names = FALSE)
  
  # Print messages about the output location
  append_to_log(paste("LCMRL.Values successfully written to:", outfh, "\n"))
  
  # Additional system information and warnings when triggered
  write(paste(" "), outfh, append = TRUE)
  
  # Debugging prints to verify flag values
  print(paste("MixedDataSet:", qc_env$MixedDataSet))
  print(paste("BadUnitsWarning:", qc_env$BadUnitsWarning))
  print(paste("RatioWarning:", qc_env$RatioWarning))
  
  if (qc_env$MixedDataSet) {  # Ensure condition matches flag type
    write("Data set contained multiple analytes some with only positive values and some with negative values. The calculated LCMRL values are compromised.", outfh, append = TRUE)
  }
  if (qc_env$BadUnitsWarning) {  # Ensure condition matches flag type
    write("Data set contained values outside of acceptable range. The calculated LCMRL values are compromised.", outfh, append = TRUE)
  }
  if (qc_env$RatioWarning) {
    write("One or more of your analytes has a highest spiking level over 20 fold greater than the LCMRL. The calculated LCMRL values are compromised.", outfh, append = TRUE)
  }
  
  write(paste("RNNR Value =", rnnr), outfh, append = TRUE)
  write(paste(R.version.string), outfh, append = TRUE)
  write(paste("LCMRL Calculator Version =", packageVersion("LCMRL")), outfh, append = TRUE)
  write(paste("Operating System =", Sys.info()[['sysname']]), outfh, append = TRUE)
  
  print(outfh)
  return("end of processing")
}

# --------------------- End LCMRL.Values ------------------------
#####################################################################

####################################################################
# ---------------------start LCMRL.Graphs --------------------------
#DIS added for dist 6/16/2020 - ASG 5/30/25 Configured to take rnnr value from GetData with fallback for Test Data
#' Generate Plots for LCMRL Calculation as .PDF (QC Interval Coverage & LCMRL Plot per analyte)
#'
#' @param fh Path/Filename of the .CSV file containing replicate data, Default = TestData
#' @param LQL lower quality limit in LCMRL specification  Default=0.5
#' @param UQL upper quality limit in LCMRL specification   Default =1.5
#' @param CPR quality interval coverage probability requirement in LCMRL specification  Default = 0.99
#' @param alph probability defining critical response (yc) in HV DL  Default = 0.05
#' @param bet = probability defining DL in HV DL: Pr(y <= yc | x = DL),  Default =0.05
#' @param rnnr Is instrument data non-negative? (1=Y, 0=N) Default = 1
#' @param outfh Output file handle, optional
#' 
#' @return None. Outputs a PDF file with generated plots.
#' 
#' @export
LCMRL.Graphs <- function(fh = defaultFH, working_directory = NULL, LQL = 0.5, UQL = 1.5, CPR = 0.99, alph = 0.05, bet = 0.05, rnnr = 1, outfh = NULL, Validate_LCMRL = FALSE) {
  # Initialize flags
  qc_env$MixedDataSet <- 0
  qc_env$BadUnitsWarning <- 0
  qc_env$RatioWarning <- 0
  
  # Check if using test data
  if (identical(fh, defaultFH) && !Validate_LCMRL) {
    qc_env$IsTestData <- 1
    fh <- system.file("extdata", "LCMRLTestData.csv", package = "LCMRL")
    outfh <- paste(working_directory, '/TestData-LCMRL.Graphs.pdf', sep = '')  # Use working_directory
    rnnr <- 1
    append_to_log("Using default reference data for LCMRL.Graphs.\n")
  } else if (is.null(outfh)) {
    fh.a <- strtrim(fh, nchar(fh) - 4)
    outfh <- paste(working_directory, paste0(basename(fh.a), "-LCMRL.Graphs.pdf"), sep = "/")
  }
  
  print(paste("Output file path:", outfh))  # Debugging statement
  
  # Read the data
  dat <- try(read.csv(fh, as.is = TRUE), silent = TRUE)
  if (inherits(dat, "try-error")) {
    append_to_log("Error reading data file.\n")
    stop("Error reading data file.")
  }
  if (ncol(dat) < 6) {
    append_to_log("Error: Number of input fields is less than 6. Check input file for missing fields.\n")
    stop("Error: Number of input fields is less than 6.")
  }
  if (ncol(dat) > 6) {
    append_to_log("Error: Number of input fields is greater than 6. Check input file for extra fields.\n")
    stop("Error: Number of input fields is greater than 6.")
  }
  
  # Extract unique analyte names
  AN <- dat[, 1]
  uniq.AN <- unique(AN)
  num.AN <- length(uniq.AN)
  
  # Open PDF for plotting
  pdf(outfh, height = 11, width = 8.5)
  
  for (kk in 1:num.AN) {
    tt <- dat[dat[, 1] == uniq.AN[kk], ]
    LabNum <- as.character(unique(tt[, 2]))
    numlabs <- length(LabNum)
    
    append_to_log(paste("Generating plots for:", uniq.AN[kk], "\n"))
    
    for (i in 1:numlabs) {
      subtt <- tt[as.character(tt[, 2]) == LabNum[i], ]
      S <- subtt[, 3]
      M <- subtt[, 4]
      AN.t <- subtt[1, 1]
      U <- try(subtt[1, 6], silent = TRUE)
      if (class(U) == "try-error") {
        U <- "ug/L"
      }
      RobLCMRL(S, M, AN.t, U, lowQL = LQL, upQL = UQL, CovProbReq = CPR, alpha = alph, beta = bet, ReqNonNegResponse = rnnr, grphs = 1, labnum = LabNum[i])
    }
  }
  
  dev.off()
  
  append_to_log(paste("LCMRL.Graphs successfully written to:", outfh, "\n"))
  
  return("end of processing")
}

# --------------------- End LCMRL.Graphs ------------------------
#####################################################################

####################################################################
# ---------------------start MRL.Stats ---------------------------------
# ASG 6-9-2025 - Converted time displayed from hours to minutes and seconds and fixed hardcoded 200 iterations to match biter used

#' Run Stats for multi-lab LCMRL data file (CSV)
#'
#' @param fh Path/Filename of the .CSV file containing multi-lab replicate data, Must specify
#' @param rnnr Flag for Required Non-Negative Response
#' @param boot.iter Number of desired bootstrap iterations. Default = 200
#' @param Seed Random seed starting value for Bayesian Weights for consistency of results, Default = "0261948". This allows results to be repeated.
#' @param Abbr Logical flag for type of output data for MRL summary, TRUE is default, FALSE for extended Output which includes un-weighted table summaries
#' @param Threads Number of threads for parallel processing. Default is NULL, which uses all available cores minus one.
#' @export
MRL.Stats <- function(fh, original_filename, rnnr = 1, boot.iter = 200, Seed = 0261948, Abbr = TRUE, Threads = NULL) {
  # Define version_info using rstudioapi if available
  if (rstudioapi::isAvailable()) {
    version_info <- rstudioapi::versionInfo()
  } else {
    version_info <- list(version = "Not available")
  }
  
  base_filename <- original_filename  # Use original_filename
  outfh <- file.path(getwd(), paste(base_filename, "-MRLTables.csv", sep = ""))
  
  # Write initial metadata and settings to the output file
  write(paste(base_filename, "-MRLTables.csv", sep = ""), outfh, append = FALSE)
  write("", outfh, append = TRUE)
  write("", outfh, append = TRUE)
  write(paste("Random Seed =", Seed), outfh, append = TRUE)
  write(paste("RNNR Value =", rnnr), outfh, append = TRUE)
  write(paste(R.version.string), outfh, append = TRUE)
  write(paste("RStudio version:", version_info$version), outfh, append = TRUE)
  write(paste("LCMRL Calculator Version =", packageVersion("LCMRL")), outfh, append = TRUE)
  write(paste("Operating System =", Sys.info()[['sysname']]), outfh, append = TRUE)
  write("", outfh, append = TRUE)
  
  # Attempt to read the CSV file, handle errors if reading fails
  dat <- try(read.csv(fh, as.is = TRUE), silent = TRUE)
  if (class(dat)[1] == "try-error") {
    print("Error:")
    print(paste(".....Problem Reading File:", fh))
    print(geterrmessage())
    return()
  }
  
  # Check if the data has exactly 6 columns
  if (length(dat[1, ]) < 6) {
    print("Error:")
    print(".....Number of input fields is less than 6")
    print(".....Check input file for missing field")
    return()
  }
  if (length(dat[1, ]) > 6) {
    print("Error:")
    print(".....Number of input fields is greater than 6")
    print(".....Check input file for extra fields")
    return()
  }
  
  # Extract analyte names and ensure uniqueness
  AN <- dat[, 1]
  uniq.AN <- unique(AN)
  num.AN <- length(uniq.AN)
  
  # Extract the Spiking Level and Measurement columns
  S <- dat[, 3]
  M <- dat[, 4]
  
  # Ensure Spiking Level and Measurement are numeric
  if (!is.numeric(S) || !is.numeric(M)) {
    print("Error")
    print("....Both the Spiking Levels and Measurements must be numeric")
    return()
  }
  
  goodflag <- 0  # Initialize flag for good labs
  
  # Initialize a list to store timing information for each analyte
  timing_info <- list()
  
  # Process each unique analyte
  for (kk in 1:num.AN) {
    # Filter data for the current analyte
    tt <- dat[dat[, 1] == uniq.AN[kk], ]
    LabNum <- as.character(unique(tt[, 2]))
    numlabs <- length(LabNum)
    BB.tmp <- matrix(0, boot.iter * numlabs, 3)
    goodlab <- 0
    goodlab.id <- NULL
    goodlab.message <- NULL
    badlab <- 0
    badlab.id <- NULL
    badlab.message <- NULL
    
    print("******************************")
    print(paste("**", "For:", uniq.AN[kk]))
    print("******************************")
    print("")
    
    write("", outfh, append = TRUE)
    write("", outfh, append = TRUE)
    write("************************************************************************", outfh, append = TRUE)
    write(paste(uniq.AN[kk], "   MRL: Summary Tables"), outfh, append = TRUE)
    write("************************************************************************", outfh, append = TRUE)
    write("", outfh, append = TRUE)
    
    # Record the start time for processing labs
    time1 <- Sys.time()
    
    print(paste("-*-*-*-* Determining which labs have usable LCMRLs"))
    
    # Process each laboratory for the current analyte
    for (i in 1:numlabs) {
      # Filter data for the current lab
      subtt <- tt[as.character(tt[, 2]) == LabNum[i], ]
      S <- subtt[, 3]
      M <- subtt[, 4]
      AN.t <- subtt[1, 1]
      
      # Attempt to get the measurement units, default to "ug/L" if missing
      U <- try(subtt[1, 6], silent = TRUE)
      if (class(U) == "try-error") { U <- "ug/L" }
      
      # Perform the LCMRL calculation for the current lab
      tmp <- RobLCMRL(S, M, AN.t, ReqNonNegResponse = rnnr, grphs = 0, labnum = LabNum[i])
      
      # Check if the LCMRL result is valid
      if (tmp$LCMRLResultFlag == 1 || tmp$LCMRLResultFlag == -1) {
        print(paste("--------Processing Lab", LabNum[i]))
        
        # Increment the count of good labs and store results
        goodlab <- goodlab + 1
        goodlab.id <- c(goodlab.id, i)
        goodlab.message <- c(goodlab.message, tmp$LCMRLResultMessage)
        
        # Perform Bayesian Bootstrap MRL calculation and store results
        BB.tmp[((goodlab - 1) * boot.iter + 1):(goodlab * boot.iter), ] <-
          BB.MRL(S, M, AN.t, U, biter = boot.iter, labnum = LabNum[i], Seed, rnnr, Threads = Threads)
        gc(verbose = FALSE)  # Run garbage collection to free memory
        
        # Store LCMRL values and flags for good labs
        if (goodlab == 1) {
          LCMRL.val <- tmp[[1]]
          labflag <- tmp$LCMRLResultFlag
        } else {
          LCMRL.val <- c(LCMRL.val, tmp[[1]])
          labflag <- c(labflag, tmp$LCMRLResultFlag)
        }
      } else {
        # Store information for labs with invalid LCMRL results
        badlab <- badlab + 1
        badlab.id <- c(badlab.id, LabNum[i])
        badlab.message <- c(badlab.message, tmp$LCMRLResultMessage)
      }
    }
    
    # Record the end time for processing labs and calculate the duration
    time2 <- Sys.time()
    elapsed <- difftime(time2, time1, units = "secs")
    elapsed_min <- as.integer(elapsed) %/% 60
    elapsed_sec <- as.integer(elapsed) %% 60
    print(paste("--------Time to do", boot.iter, "iterations per Lab:", elapsed_min, "minutes", elapsed_sec, "seconds"))
    
    # Store timing information for the current analyte
    timing_info[[uniq.AN[kk]]] <- list(minutes = elapsed_min, seconds = elapsed_sec)
    
    # Remove rows where no valid LCMRL was computed
    BB.tmp2 <- BB.tmp[BB.tmp[, 1] != "0", ]
    
    # Convert the result matrix to a data frame
    BB.tmp2 <- data.frame(BB.tmp2[, 1], as.numeric(BB.tmp2[, 2]), as.numeric(BB.tmp2[, 3]))
    
    # Check the number of good labs and write appropriate messages to the output file
    if (goodlab >= 2) {
      goodflag <- goodflag + 1
      if (goodflag == 1) {
        write("FileName", paste(base_filename, ".Rdata.filehandles.csv"), sep = "")
      }
    }
    # Handle different cases based on the number of good labs
    if (goodlab == 0) {
      write("No Laboratory had a useable LCMRL for the original Data", outfh, append = TRUE)
      write("", outfh, append = TRUE)
      if (badlab > 0) {
        for (jj in 1:badlab) {
          write(paste("......Lab", badlab.id[jj], badlab.message[jj]), outfh, append = TRUE)
        }
        write("", outfh, append = TRUE)
      }
    }
    
    if (goodlab == 1) {
      write("Only one laboratory had a good LCMRL for the original Data", outfh, append = TRUE)
      write("Therefore no MRL calculation was performed", outfh, append = TRUE)
      write("", outfh, append = TRUE)
      if (badlab > 0) {
        for (jj in 1:badlab) {
          # Write messages for labs with invalid LCMRL results
          write(paste("......Lab", badlab.id[jj], badlab.message[jj]), outfh, append = TRUE)
        }
        # Write message for the lab with a valid LCMRL result
        write(paste("......Lab", LabNum[goodlab.id[1]], "had LCMRL value", LCMRL.val[1], U, "", goodlab.message), outfh, append = TRUE)
        write("", outfh, append = TRUE)
      }
    }
    
    if (goodlab == 2) {
      # Case where exactly two labs have valid LCMRL results
      write("Only two laboratories had a useable LCMRL for the original Data", outfh, append = TRUE)
      write("Therefore only the results for ALL LABS should be used as a preliminary MRL Estimate", outfh, append = TRUE)
      write("", outfh, append = TRUE)
      if (exists("comb_negative") && comb_negative) {
        write("Warning: Lab to lab variation limit exceeded - please review data", outfh, append = TRUE)
      }
      if (badlab > 0) {
        for (jj in 1:badlab) {
          write(paste("......Lab", badlab.id[jj], badlab.message[jj]), outfh, append = TRUE)
        }
        write("", outfh, append = TRUE)
      }
      # Generate and save MRL output for the analyte
      tmp.den <- MRL.Output(uniq.AN[kk], U, BB.tmp2, labflag, LCMRL.val, boot.iter, outfh, base_filename, Abbr)
      Anal <- uniq.AN[kk]
      save(Anal, U, BB.tmp2, labflag, LCMRL.val, boot.iter, outfh, base_filename, tmp.den,
           goodlab, badlab, badlab.id, badlab.message,
           file = file.path(getwd(), paste(base_filename, "_", uniq.AN[kk], ".RData", sep = "")))
      write(file.path(getwd(), paste(base_filename, "_", uniq.AN[kk], ".RData", sep = "")), 
            file.path(getwd(), paste(base_filename, ".Rdata.filehandles.csv", sep = "")), append = TRUE)
    }
    
    if (goodlab >= 3) {
      # Case where three or more labs have valid LCMRL results
      write("Valid MRL calculated", outfh, append = TRUE)
      write("Use results for Predicted Lab as an MRL Estimate", outfh, append = TRUE)
      write("", outfh, append = TRUE)
      if (exists("comb_negative") && comb_negative) {
        write("Warning: Lab to lab variation limit exceeded - please review data", outfh, append = TRUE)
      }
      if (badlab > 0) {
        for (jj in 1:badlab) {
          write(paste("......Lab", badlab.id[jj], badlab.message[jj]), outfh, append = TRUE)
        }
        write("", outfh, append = TRUE)
      }
      # Generate and save MRL output for the analyte
      tmp.den <- MRL.Output(uniq.AN[kk], U, BB.tmp2, labflag, LCMRL.val, boot.iter, outfh, base_filename, Abbr)
      Anal <- uniq.AN[kk]
      save(Anal, U, BB.tmp2, labflag, LCMRL.val, boot.iter, outfh, base_filename, tmp.den,
           goodlab, badlab, badlab.id, badlab.message,
           file = file.path(getwd(), paste(base_filename, "_", uniq.AN[kk], ".RData", sep = "")))
      write(file.path(getwd(), paste(base_filename, "_", uniq.AN[kk], ".RData", sep = "")), 
            file.path(getwd(), paste(base_filename, ".Rdata.filehandles.csv", sep = "")), append = TRUE)
    }
  }
  
  # Check the flag and write a warning if variance clamping was enabled
  if (exists("comb_negative") && comb_negative) {
    write("Warning: Lab to lab variation limit exceeded - please review data", outfh, append = TRUE)
  }
  write("", outfh, append = TRUE)
  
  # Final output message confirming successful completion
  print(paste("MRL Summary successfully written to:", outfh))
  
  # Post-processing step to adjust headers if Abbr is TRUE
  if (Abbr) {
    # Read the entire CSV file into a vector of lines
    lines <- readLines(outfh)
    
    # Iterate over each line to find and adjust headers
    for (i in seq_along(lines)) {
      # Adjust header for each occurrence of Table 1
      if (grepl("Table 1:", lines[i])) {
        # Skip lines until we find the header line
        j <- i + 1
        while (j <= length(lines) && !grepl("LCMRL Value", lines[j])) {
          j <- j + 1
        }
        if (j <= length(lines)) {
          # Insert a blank cell at the beginning of the header line above "LCMRL Value"
          lines[j - 1] <- paste0('" "', ",", lines[j - 1])
          #cat("Adjusted Table 1 header at line", j - 1, ":", lines[j - 1], "\n")
        }
      }
      
      # Adjust header for each occurrence of Table 2
      if (grepl("Table 2:", lines[i])) {
        # Skip lines until we find the header line
        j <- i + 1
        while (j <= length(lines) && !grepl("LCMRL Value", lines[j])) {
          j <- j + 1
        }
        if (j <= length(lines)) {
          # Insert a blank cell at the beginning of the header line above "LCMRL Value"
          lines[j - 1] <- paste0('" "', ",", lines[j - 1])
          #cat("Adjusted Table 2 header at line", j - 1, ":", lines[j - 1], "\n")
        }
      }
    }
    
    # Write the adjusted lines back to the CSV file
    writeLines(lines, outfh)
    
    # Debugging: Print confirmation
    #cat("Headers adjusted and written back to file.\n")
  }
  
  # Return timing information along with other results
  return(list("end of processing", timing_info))
}

# --------------------- End MRL.Stats ------------------------
####################################################################


####################################################################
# ---------------------start MRL.Output ---------------------------------
#negative_in_bbx <- FALSE
MRL.Output <- function(An,U,BB.tmp2,labflag,LCMRL.val,boot.iter,outfh,fh.a,Abbr=TRUE)
{
  
  #densityplots of individual Labs
  labs <- unique(BB.tmp2[,1])
  numlabs <- length(labs)
  minLCMRL <- 0.0
  maxLCMRL <- max(as.numeric(BB.tmp2[,2]),na.rm=TRUE)+0.1
  
  # Create Summary Output Table
  
  # Create Table 1 Summary of Bootstrap Iteration Counts
  Table1 <- matrix(0,8,numlabs+1)
  
  Table1[2,1:numlabs] <- rep(boot.iter,numlabs)
  Table1[2,numlabs+1] <- sum(as.numeric(Table1[2,1:numlabs]))
  for(i in 1:numlabs)
  {
    Table1[3,i] <- sum(as.numeric((BB.tmp2[,1]==labs[i]))*(BB.tmp2[,3]==1),na.rm=TRUE)
    Table1[4,i] <- sum(as.numeric(BB.tmp2[,1]==labs[i])*(BB.tmp2[,3]==-1),na.rm=TRUE)
    Table1[5,i] <- sum(as.numeric(BB.tmp2[,1]==labs[i])*(is.na(BB.tmp2[,3])))
  }
  for(i in 1:numlabs)
  {
    Table1[6,i] <- 100*Table1[3,i]/Table1[2,i]
    Table1[7,i] <- 100*Table1[4,i]/Table1[2,i]
    Table1[8,i] <- 100*Table1[5,i]/Table1[2,i]
  }
  for(i in 3:5)
  {
    Table1[i,numlabs+1] <- sum(as.numeric(Table1[i,1:numlabs]))
  }
  tot <- sum(as.numeric(Table1[2,1:numlabs]))
  Table1[6,numlabs+1] <- 100* sum(as.numeric(Table1[3,1:numlabs]))/tot
  Table1[7,numlabs+1] <- 100* sum(as.numeric(Table1[4,1:numlabs]))/tot
  Table1[8,numlabs+1] <- 100* sum(as.numeric(Table1[5,1:numlabs]))/tot
  
  dimnames(Table1)[[2]] <- c(as.character(labs),"All Labs")
  Table1[1,] <- rep("Valid",numlabs+1)
  Table1[1,labflag==-1] <- "<min(SL)"
  Table1[1,numlabs+1] <- ""
  
  write("",outfh,append=TRUE)
  write(paste("Measurement Units = ",U),outfh,append=TRUE)
  write("",outfh,append=TRUE)
  write(paste("Table 1:",An,"Iteration Count Table"),outfh,append=TRUE)
  write("",outfh,append=TRUE)
  write.table(Table1,outfh,
              row.names=c("LCMRL Value","Num Iter","Valid LCMRL","< min(SL)",
                          "NA","% Valid","% < min(SL)","% NA"), sep=',', append=TRUE)
  write("",outfh,append=TRUE)
  
  # Create Table 2 Summary Stats for Individual Unweighted Labs, All Labs & Predicted Labs
  if(!Abbr)
  {
    BB.x <- na.omit(data.frame(BB.tmp2[,1],as.numeric(BB.tmp2[,2]),
                               stringsAsFactors=TRUE))
    oldBBx <- BB.x
    
    # Log BB.x for debugging ASG 9-29-25
    # write.csv(BB.x, file = paste0(fh.a, "_BB_x.csv"), row.names = FALSE)
    
    # get lambda from box cox multivariate normal
    lamb <- powerTransform(BB.x[,2] ~ BB.x[,1])$lambda
    if( lamb > 0 )
    { BB.x[,2] <- BB.x[,2]^lamb} else
    { BB.x[,2] <- log(BB.x[,2])}
    
    
    # Log transformed BB.x for debugging ASG 9-29-254
    # write.csv(BB.x, file = paste0(fh.a, "_BB_x_transformed.csv"), row.names = FALSE)
    
    BB.labx <- split(BB.x[, 2], BB.x[, 1])
    BB.locvar <- sapply(BB.labx, roblocvar4, cc = 6)
    
    # Log BB.locvar for debugging ASG 9-29-25
    # write.csv(as.data.frame(BB.locvar), file = paste0(fh.a, "_BB_locvar.csv"), row.names = FALSE)
    
    #within lab variance  is the mean of the robust lab variances
    with.var <-  mean(as.numeric(BB.locvar[2,]))
    # between lab variance is variance of the robust lab means
    betw.var <- var(as.numeric(BB.locvar[1,]))
    # grand mean is the mean of the robust lab means
    x.bar <- mean(as.numeric(BB.locvar[1,]))
    k <- length(BB.labx)
    S.L <- (1+1/k)*betw.var + with.var
    xij <- sort(x.bar + sqrt(S.L)*unlist(std.z(BB.labx,BB.locvar)))
    xij <- xij[xij > 0]
    if( lamb > 0 )
    {
      xij <- xij[xij>0]
      xij <- exp(log(xij)/lamb)
    } else
    {
      xij <- exp(xij)
    }
    
    # Log xij for debugging ASG 9-29-25
    # write.csv(data.frame(xij), file = paste0(fh.a, "_xij.csv"), row.names = FALSE)
    
    BB.x <- oldBBx
    Table2 <- matrix(0,22,numlabs+2)
    tlabs <-c(as.character(labs),"ALL Labs","Predicted Lab")
    dimnames(Table2)[[2]] <- tlabs
    pcts <-c(0.05,0.10,0.20,0.25,0.50,0.60,0.70,0.75,0.80,0.85,0.90,0.95,0.96,0.97,0.98,0.99)
    
    for(i in 1:numlabs)
    {
      Table2[2,i] <-min(BB.x[BB.x[,1]==tlabs[i],2],na.rm=T)
      Table2[19,i] <- max(BB.x[BB.x[,1]==tlabs[i],2])
    }
    for(i in 1:numlabs)
    {
      st <- sort(BB.x[BB.x[,1]==tlabs[i],2])
      Table2[3:18,i] <- quantile(st,probs=pcts,names=F)
      Table2[20,i] <- mean(st)
      Table2[21,i] <- sd(st)
      Table2[22,i] <- Table2[21,i]/Table2[20,i]
    }
    Table2[2,numlabs+1] <-min(BB.x[,2])
    Table2[19,numlabs+1] <- max(BB.x[,2])
    st <- sort(BB.x[,2])
    Table2[3:18,numlabs+1] <- quantile(st,probs=pcts,names=F)
    Table2[20,numlabs+1] <- mean(st)
    Table2[21,numlabs+1] <- sd(st)
    Table2[22,numlabs+1] <- Table2[21,numlabs+1]/Table2[20,numlabs+1]
    
    Table2[2,numlabs+2] <-min(xij)
    Table2[19,numlabs+2] <- max(xij)
    Table2[3:18,numlabs+2] <- quantile(xij,probs=pcts,names=F)
    Table2[20,numlabs+2] <- mean(xij)
    Table2[21,numlabs+2] <- sd(xij)
    Table2[22,numlabs+2] <- Table2[21,numlabs+2]/Table2[20,numlabs+2]
    Table2[1,] <- c(LCMRL.val,"","")
    write("Table 2: Unweighted Data: Percentiles of LCMRL Bootstrap Dist.",
          outfh,append=TRUE)
    write("",outfh,append=TRUE)
    write.table(Table2,outfh,
                row.names=c("LCMRL Value","minimum","5%","10%","20%","25%","50%","60%","70%","75%",
                            "80%","85%","90%","95%","96%","97%","98%","99%","maximum",
                            "mean","std.dev","cv"),sep=',',append=TRUE)
    write("",outfh,append=TRUE)
    
    
    
    
    # Create Table 3 Guttman UTLs for Unweighted Data
    
    write("Table3: Unweighted Data: Upper Tol. Limits for 95% Probablity of p% Coverage",
          outfh,append=TRUE)
    write("",outfh,append=TRUE)
    
    Table3 <- matrix(0,6,numlabs+2)
    dimnames(Table3)[[2]] <-c(as.character(labs),"ALL Labs","Predicted Lab")
    #dimnames(Table3)[[2]] <- c("", as.character(labs), "ALL Labs", "Predicted Lab") # 10-14-25 ASG alignment fix
    #spaces <- c(""," ","   ","    ","     ","      ","       ","       ")
    #names(Table3) <- list(spaces[1:numlabs+2])
    #for(i in 1:(numlabs)) { Table3[i[i]] <- c("","","","","") }
    Table3[1,1:numlabs] <- c(LCMRL.val)
    Table3[2:6,numlabs+1] <- c(guttman.utl(st,0.95,0.70),
                               guttman.utl(st,0.95,0.75),guttman.utl(st,0.95,0.80),
                               guttman.utl(st,0.95,0.90),guttman.utl(st,0.95,0.95))
    Table3[2:6,numlabs+2] <- c(guttman.utl(xij,0.95,0.70),
                               guttman.utl(xij,0.95,0.75),guttman.utl(xij,0.95,0.80),
                               guttman.utl(xij,0.95,0.90),guttman.utl(xij,0.95,0.95))
    Table3[1,(numlabs+1):(numlabs+2)] <- c("","")
    Table3[2:6,1:numlabs] <- ""
    write.table(Table3,outfh,,append=TRUE,row.names=c("LCMRL Value","95-70 UTL","95-75 UTL",
                                                      "95-80 UTL","95-90 UTL",
                                                      "95-95 UTL"), sep=',')
    write("",outfh,append=TRUE)
  }
  # Create Table 4  Guttman UTLs for One sided Tukey Weighted Data
  
  if(!Abbr)
  {
    write("Table4: Weighted Data: Upper Tol. Limits for 95% Probablity of p% Coverage",
          outfh,append=TRUE)
    write("",outfh,append=TRUE)
  } else
  {
    write("Table 2: Weighted Data: Upper Tol. Limits for 95% Probablity of p% Coverage",
          outfh,append=TRUE)
    write("",outfh,append=TRUE)
  }
  
  BB.x <- na.omit(data.frame(BB.tmp2[,1],as.numeric(BB.tmp2[,2]),
                             stringsAsFactors=TRUE))
  Table4 <- matrix(0,6,numlabs+2)
  dimnames(Table4)[[2]] <-c(as.character(labs),"ALL Labs","Predicted Lab") #Original misaligned code ASG 10-15-25
  st <- sort(BB.x[,2])
  median.st <- median(st)
  mad.st <- mad(st)
  st <- sort(st)
  tw1.lst <- wt.bw.1.sided(st,median.st,mad.st,cc=6,reltol=1e-6,maxsteps=100)
  #csum.st <- cumsum(tw1.lst[[2]])
  new.loc <- tw1.lst[[1]]
  utl70 <- wgt.guttman.utl(st,tw1.lst[[2]],.95,.70)
  utl75 <- wgt.guttman.utl(st,tw1.lst[[2]],.95,.75)
  utl80 <- wgt.guttman.utl(st,tw1.lst[[2]],.95,.80)
  utl90 <- wgt.guttman.utl(st,tw1.lst[[2]],.95,.90)
  utl95 <- wgt.guttman.utl(st,tw1.lst[[2]],.95,.95)
  Table4[1,1:numlabs] <- c(LCMRL.val)
  Table4[2:6,numlabs+1] <- c(utl70,utl75,utl80,utl90,utl95)
  
  # Check for zero or negative values and apply log1p transformation ASG 9-29-25
  # if (any(BB.x[, 2] <= 0)) {
  #  BB.x[, 2] <- log1p(BB.x[, 2])
  #  negative_in_bbx <<- TRUE
  #  print("negative_in_bbx set to TRUE due to zero or negative values in BB.x")
  # } 
  #  else {
  #  print("negative_in_bbx remains FALSE")
  # }
  
  # Log transformed BB.x for debugging ASG 9-29-25
  # write.csv(BB.x, file = paste0(fh.a, "_BB_x_transformed.csv"), row.names = FALSE)
  
  # get lambda from box cox multivariate normal
  lamb <- powerTransform(BB.x[,2] ~ BB.x[,1])$lambda
  if( lamb > 0 ) { 
    BB.x[,2] <- BB.x[,2]^lamb
  } else {
    BB.x[,2] <- log(BB.x[,2])
  }
  
  # Log BB.x after transformation ASG 9-30-25
  # write.csv(BB.x, file = paste0(fh.a, "_BB_x_after_transformation2.csv"), row.names = FALSE)
  
  med.x <- median(BB.x[,2])
  mad.x <- mad(BB.x[,2])
  BB.x.wgt.lst <- wt.bw.1.sided(BB.x[,2],med.x,mad.x,c=6,reltol=1e-6,maxsteps=100)
  if(any(BB.x.wgt.lst[[2]] == 0 ))
  {BB.x.wgt.lst <- wt.bw.1.sided(BB.x[,2],med.x,mad.x,c=9,reltol=1e-6,maxsteps=100)}
  BB.x <- cbind(BB.x[1],BB.x[2],BB.x.wgt.lst[[2]])
  BB.labx <- split(BB.x[,2],BB.x[,1])
  BB.labwts <- split(BB.x[,3],BB.x[,1])
  BB.labels <- split(BB.x[,1],BB.x[,1] )
  BB.locvar <- matrix(0,2,length(BB.labx))
  nlabs <-length(BB.labx)
  for(i in 1:nlabs)
  {
    tmp <- roblocvar4(BB.labx[[i]],cc=6)
    BB.locvar[1,i] <- tmp[[1]]
    BB.locvar[2,i] <- tmp[[2]]
  }
  sum.wgts <-sapply(BB.labwts,sum)
  #within lab variance is weighted average of lab robust means
  with.var <-  sum(as.numeric(BB.locvar[2,])*sum.wgts )
  # between lab variance is the weighted variance of the robust lab means
  betw.var <- w.var(as.numeric(BB.locvar[1,]),sum.wgts)
  # grand mean
  x.bar <- sum(as.numeric(BB.locvar[1,])*sum.wgts)
  
  # Log variance and mean calculations to CSV ASG 9-29-25
  # write.csv(data.frame(with.var = with.var), file = paste0(fh.a, "_with_var.csv"), row.names = FALSE)
  # write.csv(data.frame(betw.var = betw.var), file = paste0(fh.a, "_betw_var.csv"), row.names = FALSE)
  # write.csv(data.frame(x.bar = x.bar), file = paste0(fh.a, "_x_bar.csv"), row.names = FALSE)
  
  k <- length(BB.labx)
  S.L <- (1+1/k)*betw.var + with.var
  BB.labx2 <- BB.labx
  
  # Initialize the flag for negative values ASG 9-30-25
  BB.labx2_negative_flag <<- FALSE
  
  # Log BB.labx2 for debugging ASG 9-30-25
  # write.csv(data.frame(unlist(BB.labx2)), file = paste0(fh.a, "_BB_labx2_before.csv"), row.names = FALSE)
  
  
  # Mitigation proved unreliable and unneeded, reverted back to original code here ASG 10-3-25
  # for(i in 1:nlabs) {
  #standardized_values <- std2.z(BB.labx[[i]], BB.locvar[, i])
  #adjusted_values <- x.bar + sqrt(S.L) * standardized_values
  
  # Check for values less than or equal to zero and set them to a small positive value ASG 9-30-25 Mitigation
  #if (any(adjusted_values <= 0)) {
  #BB.labx2_negative_flag <<- TRUE
  # adjusted_values[adjusted_values <= 0] <- 0.000001
  #print("BB.labx2_negative_flag set to TRUE")
  #}
  
  #BB.labx2[[i]] <- adjusted_values
  #}
  
  #old version ASG 9-30-25
  for(i in 1:nlabs)
  {
    BB.labx2[[i]]<- x.bar + sqrt(S.L)*std2.z(BB.labx[[i]],BB.locvar[,i])
  }
  
  # Log BB.labx2 for debugging ASG 9-29-25
  # write.csv(data.frame(unlist(BB.labx2)), file = paste0(fh.a, "_BB_labx2.csv"), row.names = FALSE)
  
  sxij <- sort(unlist(BB.labx2),index=TRUE)
  
  # Log sxij for debugging ASG 9-29-25
  # write.csv(data.frame(sxij), file = paste0(fh.a, "_sxij.csv"), row.names = FALSE)
  
  # check for useable values
  if(lamb > 0 )
  {
    xij <- sxij$x
    for( i in 1:length(sxij$x))
    {
      xij[i] <- ifelse(sxij$x[i]>0,exp(log(sxij$x[i])/lamb),0)
    }
  } else
  {
    xij <- exp(sxij$x)
  }
  wt.x <- unlist(BB.labwts)[sxij$ix]
  BB.labels <- unlist(BB.labels)[sxij$ix]
  
  
  
  utl70 <- wgt.guttman.utl(xij,wt.x,.95,.70)
  utl75 <- wgt.guttman.utl(xij,wt.x,.95,.75)
  utl80 <- wgt.guttman.utl(xij,wt.x,.95,.80)
  utl90 <- wgt.guttman.utl(xij,wt.x,.95,.90)
  utl95 <- wgt.guttman.utl(xij,wt.x,.95,.95)
  Table4[2:6,numlabs+2] <- c(utl70,utl75,utl80,utl90,utl95)
  Table4[1,(numlabs+1):(numlabs+2)] <- c("","")
  Table4[2:6,1:numlabs] <- ""
  write.table(Table4,outfh,,append=TRUE,row.names=c("LCMRL Value","95-70 UTL","95-75 UTL",
                                                    "95-80 UTL","95-90 UTL",
                                                    "95-95 UTL"), sep=',')
  
  comb.dat <- cbind("All Labs",st)
  comb.dat <- rbind(comb.dat,cbind("Predicted Lab",xij))
  
  # Log comb.dat for debugging ASG 9-29-25
  # write.csv(comb.dat, file = paste0(fh.a, "_comb_dat.csv"), row.names = FALSE)
  
  # Initialize the flag for negative or zero values
  comb_negative <<- FALSE
  
  # sloppy mitigation attempt, do not use in final product ASG 10-3-25
  # comb.dat[, 2] <- ifelse(comb.dat[, 2] == 0, 0.000001, comb.dat[, 2])
  # sloppy first attempt
  if (any(comb.dat[, 2] <= 0)) {
    comb.dat[comb.dat[, 2] <= 0, 2] <- 0.00000000000000001
    comb_negative <<- TRUE
  }
  # Less sloppy followup ASG 10-3-25
  
  # Log clamped comb.dat for debugging ASG 10-3-25
  # write.csv(comb.dat, file = paste0(fh.a, "_comb_dat_clamped.csv"), row.names = FALSE)
  
  pos1 <- quantile(density(xij)$y,0.9)
  pos2 <- quantile(density(log10(xij))$y,0.9)
  BB.p <- na.omit(data.frame(BB.tmp2[,1],as.numeric(BB.tmp2[,2]),
                             stringsAsFactors=TRUE))
  BB.lst <- split(BB.p[,2],BB.p[,1])
  BB.pos <- sapply(BB.lst,density)
  BB.q <-sapply(BB.pos[2,],quantile,probs=0.9)
  posA <- max(BB.q)
  BB.log <- sapply(BB.pos[2,],log10)
  BB.q <- sapply(BB.log,quantile,probs=0.9)
  posB <- max(BB.q)
  pdf(paste(fh.a,"_",An,"_","DensityPlots.pdf",sep=""),height=11,width=8.5)
  # DENSITYPLOTS of individual Labs
  ##  OLD densityplot syntax  DIS 03/29/2021
  #  dplot1 <- densityPlot(~BB.p[,2]|as.factor(BB.p[,1]),
  #      layout=c(1,numlabs),xlab="Spiking Level",
  #      na.rm=TRUE,pch="|",cex=0.2,
  #      main =paste("Density Plots of Labs \n",paste(An,"  ",U)),
  #      panel=function(x)
  #         {
  #         panel.densityplot(x)
  #         panel.abline(v=utl75,col="red")
  #         panel.text(utl75,posA,labels=paste(" MRL = ",sprintf("%.2f",utl75)),col=2,pos=4,cex=0.8)
  #         }
  #      )
  dplot1 <- densityPlot(~BB.p[,2], g=as.factor(BB.p[,1]),
                        xlab="Spiking Level",
                        na.rm=TRUE,
                        main=paste("Density Plots of Labs \n",paste(An," ",U))
  )
  abline(v=utl75,col="red")
  text(utl75,posA,labels=paste(" MRL = ",sprintf("%.2f",utl75)),col=2,pos=4,cex=0.8)
  
  dplot2 <- densityPlot(~log10(BB.p[,2]), g=as.factor(BB.p[,1]),
                        xlab="Spiking Level (log)",
                        na.rm=TRUE,
                        main =paste("Density Plots of Labs \n",paste(An,"  ",U)),
  )
  abline(v=log10(utl75),col="red")
  text(log10(utl75),posB,labels=paste(" log(MRL) = ",sprintf("%.2f",log10(utl75))),col=2,pos=4,cex=0.8)
  
  # DENSITYPLOTS of Weighted ALL LABS & PREDICTED LAB
  dplot3 <- densityPlot(~as.numeric(comb.dat[,2]), g=as.factor(comb.dat[,1]),
                        xlab="Spiking Level", na.rm=TRUE,
                        main =paste("Density Plots of Combined Labs \n",paste(An,"  ",U))
  )
  abline(v=utl75,col="red")
  text(utl75,pos1,labels=paste(" MRL = ",sprintf("%.2f",utl75)),col=2,pos=4,cex=0.8)
  
  dplot4 <- densityPlot(~log10(as.numeric(comb.dat[,2])), g=as.factor(comb.dat[,1]),
                        xlab="Spiking Level", na.rm=TRUE,
                        main =paste("Density Plots of Combined Labs \n",paste(An,"  ",U))
  )
  abline(v=log10(utl75),col="red")
  text(log10(utl75),pos2,labels=paste(" log(MRL) = ",sprintf("%.2f",log10(utl75))),col=2,pos=4,cex=0.8)
  
  dev.off()
  write("",outfh,append=TRUE)
  
  return(list(dplot1,dplot2,dplot3,dplot4))
}
# ---------------------End MRL.Output----------------------------------
#######################################################################

####################################################################
# ---------------------BB.MRL Start ---------------------------------
# ASG - 6-9-2025 profiling showed 95% of CPU spent here, introduced parallelization for dramatic speedup
#
# This code performs a bayesian bootstrap on the spiking level and
# measurement data generating a distribution of the LCMRL values.
#
# ----------------Inputs-------------------------------------
#
# S - vector of Spiking levels
# M - vector of Measurements at Spiking Levels
# AN - analyte name
# U- measurement units. Default = 'ug/l'
# biter - number of bootstrap iterations. Default = 200
# Seed - Random Seed. Default set at 0261948. Ensures consecutive runs give
#        identical results
# rnnr = flag for Required Non-Negative Response
#        1 is for Required Non-Negative Response
#        0 is for Negative Response Allowed
# ----------------Outputs ------------------
#
# BB.mat - a matrix of LCMRL values and Result flags with dim = (biter,2 or 3)
#     BB.mat[,1] - LCMRL values for each bootstrap iteration
#     BB.mat[,2] - LCMRLResultflag
# ----------------Start code---------------------------------
#

BB.MRL <- function(S, M, AN, U, biter = 200, labnum = NULL, Seed, rnnr = 1, Threads = NULL) {
  library(foreach)
  library(doParallel)
  
  # Determine the number of cores to use
  cores <- if (is.null(Threads)) {
    parallel::detectCores() - 1
  } else {
    Threads
  }
  cl <- makeCluster(cores)
  registerDoParallel(cl)
  
  ncol <- ifelse(is.null(labnum), 2, 3)
  dim_names <- list(NULL, c('Lab', 'LCMRL', 'ResultFlag'))
  
  # Generate bootstrap weights
  BB.1.wgts <- Bayes.1.Boot(S, biter, Seed)
  
  # Parallel loop using foreach
  BB.list <- foreach(i = 1:biter, .combine = rbind, .packages = c("LCMRL")) %dopar% {
    tmptry <- try(
      RobLCMRL(S, M, AN, U, ReqNonNegResponse = rnnr, grphs = 0, BW = BB.1.wgts[i, ]),
      silent = TRUE
    )
    gc(verbose = FALSE)
    
    if (inherits(tmptry, "try-error")) {
      return(c(labnum, NA, NA))
    } else if (tmptry[2] == -1 || tmptry[2] == 1) {
      return(c(labnum, tmptry))
    } else {
      return(c(labnum, NA, NA))
    }
  }
  
  stopCluster(cl)
  
  dimnames(BB.list) <- dim_names
  return(BB.list)
}

# --------------------- BB.MRL End --------------------------------- 
####################################################################


####################################################################
# ---------------------Start RobLCMRL ---------------------------------

RobLCMRL <- function(SpikeConc,MeasConc,AnalName,
                     strUnits="ug/L",lowQL=0.5,upQL=1.5,
                     CovProbReq=0.99,alpha=0.05,beta=0.05,ReqNonNegResponse=1,
                     grphs=1,labnum=NULL,BW =rep(1,length(SpikeConc)))
  
  # ----------------Outputs------------------------------------
# Returns a list with names:
#
# LCMRLval = numerical value of LCMRL
# DLval = numerical value of Hubaux-Vos detection limit
# CLval = numerical value of critical level
# R = correlation : numerical
# R2 = R-squared : numerical
# R2adj = adjusted R-squared L: numerical
# LCMRLResultFlag = result flag for LCMRL : numerical
# LCMRLResultMessage = result message for LCMRL : string
#     -4 'Aborted: Not enough non-zero Spiking Levels
#     -3 'Nonconvergence: '
#     -2 'LCMRL is above highest spiking level'
#     -1 'Lower spiking level needed to bracket the LCMRL'
#      0 - not set
#      1 'Valid LCMRL'
# DLResultFlag = result flag for HV DL  : numerical
# DLResultMessage = result message for HV DL  : string
#     -3 - 'Nonconvergence: ' output.message
#     -2 - 'PROBLEM: DL appears to be above max spiking level'
#      0 - not set
#      1 - 'Valid DL'
#      2  - 'DL calculated >= LCMRL; set DL = LCMRL'
# Var.Model = a glm object representing the Var Model
# Means.Model = a lm object representing the Means Model
# MSE.Model = a glm object representing the Condtional MSE Model
# ----------------Inputs-------------------------------------
#
# SpikeConc = vector of spiking concentrations
# MeasConc = vector of measured concentrations
# AnalName = analyte name
# strUnits = units of measurement Default = "mg/L"
# lowQL = lower quality limit in LCMRL specification  Default=0.5
# upQL = upper quality limit in LCMRL specification   Default =1.5
# CovProbReq = quality interval coverage probability requirement in LCMRL
#   specification  Default = 0.99
# alpha = probability defining critical response (yc) in HV DL  Default = 0.05
# beta = probability defining DL in HV DL: Pr(y <= yc | x = DL),  Default =0.05
# ReqNonNegResponse = Is instrument data non-negative? (1=Y, 0=N) Default = 1
# grphs = switch for graphical output 0= no output, 1= LCMRL output, Default=1
# labnum = laboratory number. Used only with MRL estimation in multi-lab-studies
# BW - normalized vector of Bayesian Weights used for MRL calculations.
#      Default is set to vector of 1's the length of SpikeConc to produce the
#      original LCMRL calculation. For the MRL the weights are generated by
#      Bayes.1.Boot() in BB.MRL()
# -------------------------Begin RobLCMRL ------------------------------
{
  theta <- 1e-6
  maxIter <- 100
  DnuSL <- NULL
  LowLimLCMRL <- 0
  RecoveryRange = paste(as.character(round(lowQL*100)),'-',as.character(round(upQL*100)),'%',sep='')
  
  ##  Add annotation flag for plots where default parameters were not used
  if(lowQL==0.5 && upQL==1.5 && CovProbReq==0.99 && alpha==0.05 && beta==0.05){defParFlag=T}else{defParFlag=F}
  
  xs <- sort(SpikeConc,index=TRUE)
  x <- xs$x
  y <- MeasConc[xs$ix]
  xorg <- x    # save orgibnal x values
  yorg <- y    # save original y values
  BWorig <- BW
  
  ###
  # Data Conditioning
  ###
  
  # temporary fix, don't allow negative results if ReqNonNegResponse =1
  if( ReqNonNegResponse ==1) { y <- y*(y>=0) }
  
  
  MinNZResp <- min(y[y>0])    # find min NZ response
  ZeroSubstVal <- MinNZResp/2 # 0 response substitution value for certain situations
  
  # check for 0 results at NZ SL
  xnzsl <- x[x>0]  # get NZ spike values
  ynzsl <- y[x>0]  # get corresponsing measurements
  ZeroRespFlag <- any(ynzsl==0)
  if (ZeroRespFlag)
  {
    # check for fraction 0 response at NZ SL
    ZeroRespSL <- unique(xnzsl[ynzsl==0]) # get list of NZ SL with 0 response
    LowLimLCMRL <- min(x[x>max(ZeroRespSL)]) # smallest SL with no 0 responses
    LowLimDL <- LowLimLCMRL # since there should be no 0 response at DL
    nLvls <- length(ZeroRespSL) #count number of the SL
    FracNZResp <- vector("numeric",nLvls)
    for ( i in 1:nLvls )
    {
      ytmp <- ynzsl[xnzsl==ZeroRespSL[i]]
      FracNZResp[i]<- sum(ytmp>0)/length(ytmp)  # compute fraction NZ response
      if ( FracNZResp[i]>=0.5 ) # for NZ SL with 0 response fraction between 0.5 and 1
      {
        ytmp[ytmp==0] <- ZeroSubstVal; # replace 0 responses with half min NZ response
        ynzsl[xnzsl==ZeroRespSL[i]] <- ytmp
      }
    }
    DnuSL <- ZeroRespSL[FracNZResp<0.5]
    if ( (length(unique(x)) - length(DnuSL)) < 4) # check to make sure there
      # are enough remaining SL
      # for valid estimates
    {
      LCMRLResultFlag <- -4;
      LCMRLResultMessage <- 'Aborted: Not enough spiking levels with nonzero
                                 results';
      DLResultFlag <- -4;
      DLResultMessage <- 'Aborted: Not enough spiking levels with nonzero
                              results';
      dat.tmp <-list(NA,NA,NA,LCMRLResultFlag,LCMRLResultMessage )
      names(dat.tmp) <- list('LCMRLval','DLval','CLval','LCMRLResultFlag',
                             'LCMRLResultMessage')
      return(dat.tmp)
    }
    
    Nall0Resp <- sum(FracNZResp==0);
    if (Nall0Resp)
    {
      if (Nall0Resp > 1)
      {
        warning(' Nonzero spiking levels have all 0 responses')
      } else
      {
        warning('One nonzero spiking level has all 0 responses')
      }
      warning(' This indicates a quality problem with the data.')
    }
  }
  
  n <- length(xorg) # number of original data points
  if(!is.null(DnuSL))
  {
    UseIndex <- !is.element(x, DnuSL) # find index of observations to use in models
    x <- xorg[UseIndex] #subset x
    y <- yorg[UseIndex] # subset y
    BW <- BW[UseIndex]
  } else
  {
    x <- xorg
    y <- yorg
    BW <- BWorig
  }
  n <- length(x)
  normBW <- BW/sum(BW)
  xbar <- sum(normBW*x)
  #ssx <- n*sum(normBW*(x-xbar)^2)
  ssx <- n*sum(normBW*(x-xbar)^2)
  # plot raw data
  #plot(x,y, xlab=paste("SpikeConc"," ","(",strUnits,")"), ylab="MeasConc",
  #      main=AnalName)
  
  #compute replicate variances using robust w-estimator
  tmp <- RobRepVar(x,y,aPwts=BW)
  SpikeLevels <- tmp[[1]]
  RobVars <- tmp[[2]]
  RobLoc <- tmp[[3]]
  RobWt <- tmp[[4]]
  RepVarDoF <- tmp[[5]]
  nLevels <- tmp[[6]]
  remove(tmp)
  #plot(SpikeLevels,RobVars,xlab=paste("SpikeConc"," ","(",strUnits,")"),
  #     ylab="RobVars", main=AnalName)
  # assemble vector of robust weights, uses all data
  robWts <-unlist(RobWt)
  
  # check for 0 spiking level (method blanks) and remove for replicate
  # variance model calc
  if (SpikeLevels[1]==0 )
  {
    VarSpikeLevels <- SpikeLevels[2:nLevels]
    RobVars <- RobVars[2:nLevels]
    RepVarDoF <- RepVarDoF[2:nLevels]
    nvLevels <- nLevels-1
  } else
  {
    VarSpikeLevels <- SpikeLevels
    nvLevels <- nLevels
  }
  if (nvLevels < 4)
  {
    LCMRLResultFlag <- -4;
    LCMRLResultMessage <- 'Aborted: Not enough spiking levels with all nonzero results'
    warning(LCMRLResultMessage)
    DLResultFlag <- -4;
    DLResultMessage <- 'Aborted: Not enough spiking levels with all nonzero
                            results';
    dat.tmp <-list(NA,NA,NA,LCMRLResultFlag,LCMRLResultMessage )
    names(dat.tmp) <- list('LCMRLval','DLval','CLval','LCMRLResultFlag',
                           'LCMRLResultMessage')
    return(dat.tmp)
  }
  
  #Check for 0 variances
  if (all(RobVars == 0 ) )
  {
    stop("All replicate variances are 0. Likely cause is data entry error")
  }
  if( any(RobVars == 0))
  {
    warning(paste("Warning: One or more replicate variances is 0. ",
                  "Likely causes are data entry error or variance damping (due",
                  " to insufficient digits, smoothing or thresholding"))
    VarOK <- (RobVars > 0)
    VarSpikeLevels <- VarSpikeLevels[VarOK]
    RobVars <- RobVars[VarOK]
    RepVarDoF <- RepVarDoF[VarOK]
    nvLevels <- length(VarSpikeLevels)
  }
  
  # estimate variance model
  
  Vtmp <- VarMod(VarSpikeLevels,RobVars,RepVarDoF)
  gc(verbose=FALSE)
  VarFnPar <- Vtmp
  
  # estimate means model
  m.mod <- IRLS(x,y,VarFnPar,robWts,ReqNonNegResponse,theta,maxIter,grphs,LN=labnum,BW)
  gc(verbose=FALSE)
  #print("########## end of IRLS")
  #print(m.mod)
  
  MeanFnPar <- m.mod[[1]]
  MSEFnPar <- m.mod[[2]]
  R2adj <-m.mod[[3]]
  Cp <- m.mod[[4]]
  pred <-m.mod[[5]]
  resids <-m.mod[[6]]
  residPearson <-m.mod[[7]]
  S_StdRes <-m.mod[[8]]
  cMSE <- m.mod[[9]]
  cmseSpikeLevels <- m.mod[[10]]
  Means.Model <- m.mod[[11]]
  
  # predicted MSE
  if( MSEFnPar$type == 'constant')
  {
    predMSE <- MSEFnPar$a*rep(1,nLevels)
  } else
  {
    predMSE <- pmax(MSEFnPar$a + MSEFnPar$b * SpikeLevels^MSEFnPar$c,
                    rep(MSEFnPar$minVar,nLevels))
  }
  
  # plot conditional MSE model
  
  # check for 0 spiking level (method blanks) and remove for LCMRL calc
  LCMRLSpikeLevels <- SpikeLevels
  if( SpikeLevels[1] == 0 )
  {
    LCMRLSpikeLevels <- SpikeLevels[2:nLevels]
  } else
  {
    LCMRLSpikeLevels <- SpikeLevels
  }
  
  # compute LCMRL
  LCMRL.tmp <-
    srchLCMRL(LCMRLSpikeLevels,lowQL,upQL,MeanFnPar,VarFnPar,MSEFnPar,
              CovProbReq,n,xbar,ssx,ReqNonNegResponse,LowLimLCMRL )
  LCMRLval <- LCMRL.tmp[[1]][[1]]
  CovProbMat <- LCMRL.tmp[[2]]
  LCMRLResultFlag <- LCMRL.tmp[[3]]
  LCMRLResultMessage <- LCMRL.tmp[[4]]
  
  # for MRL calculations return only LCMRLval & LCMRLResultflag
  if( !all(BW == 1) ) { return(c(LCMRLval,LCMRLResultFlag )) }
  
  # compute HV DL
  if(ZeroRespFlag)
  {
    HVDL.lst <- HubauxVos(MeanFnPar,VarFnPar,MSEFnPar,alpha,beta,
                          LCMRLval,LCMRLSpikeLevels,ReqNonNegResponse,ZeroRespFlag)
  } else
  {
    HVDL.lst <- HubauxVos(MeanFnPar,VarFnPar,MSEFnPar,alpha,beta,
                          LCMRLval,SpikeLevels,ReqNonNegResponse,ZeroRespFlag)
  }
  
  DLval <- HVDL.lst[[1]]
  CLval <- HVDL.lst[[2]]
  HVResultFlag <- HVDL.lst[[3]]
  HVResultMessage <- HVDL.lst[[4]]
  
  # GRAPHICAL OUTPUT
  if( grphs > 0  && (LCMRLResultFlag==1 || LCMRLResultFlag==-1) )
  {
    #par(ask=TRUE)
    xpts <- CovProbMat[,1]
    ypts <- CovProbMat[,2]
    npts <- length(xpts)
    dof <- MSEFnPar$DoF
    
    # create mean and variance vectors
    mu <- MeanFn(xpts,MeanFnPar)
    v <- VarFn(xpts,MSEFnPar)*(1+1/n+((xpts-xbar)^2)/ssx)
    
    # probability levels for upper and lower prediction
    lcmrlLowProb <- (1-CovProbReq)/2
    lcmrlUpProb <- 1-lcmrlLowProb
    lowPred <- vector("numeric",npts)
    upPred <- vector("numeric",npts)
    
    # build vectors for moment inequalty check
    std <- sqrt(v)
    M <- mu +3*std
    
    if(ReqNonNegResponse == 1)
    {
      for( i in 1:npts)
      {
        if( v[i] <= mu[i]*(M[i]-mu[i]) ) # if moment ineq. OK use gamma
        {
          gpars <- GammaPars(mu[i],v[i])
          lowPred[i] <- qgamma(lcmrlLowProb,gpars[[1]],scale=gpars[[2]])
          upPred[i] <- qgamma(lcmrlUpProb,gpars[[1]],scale=gpars[[2]])
        } else     # otherwise use truncted t
        {
          z <- qt(pt(-mu[i]/std[i],dof) + lcmrlLowProb*pt(-mu[i]/std[i],dof))
          lowPred[i] <- mu[i]+z*std[i]
          z <- qt(pt(-mu[i]/std[i],dof) + lcmrlUpProb*pt(-mu[i]/std[i],dof))
          upPred[i] <- mu[i]+z*std[i]
        }
      }
    } else
    {
      lowPred <- mu + qt(lcmrlLowProb,dof)*sqrt(v)
      upPred  <- mu + qt(lcmrlUpProb, dof)*sqrt(v)
    }
    maxS <- max(SpikeConc)
    MinCov <- min(CovProbMat[,2],CovProbReq)
    xlow <-  min(xpts)/2
    
    # plot LCMRL in terms of QC interval coverage probability
    
    if(is.null(labnum))
    {
      plot(xpts,ypts,main=paste(AnalName,"QC Interval Coverage Plot"),
           xlab=paste("True Concentration"," (",strUnits,")"),
           ylab="Probability of QC Interval Coverage",
           xlim=c(0,maxS),ylim=c(0.96*MinCov, 1.0),
           pch="", ask=TRUE)
    } else
    {
      plot(xpts,ypts,main=paste(AnalName,"Lab",
                                labnum,"\n","QC Interval Coverage Plot"),
           xlab=paste("True Concentration"," (",strUnits,")"),
           ylab="Probability of QC Interval Coverage",
           xlim=c(0,maxS),ylim=c(0.96*MinCov, 1.0),
           pch="", ask=TRUE)
    }
    lines(xpts,ypts,col='blue')
    lines(c(LCMRLval,LCMRLval),c(0.96*MinCov,CovProbReq),lty=2)
    lines(c(0,maxS),c(CovProbReq,CovProbReq),lty=2, col='red')
    points(LCMRLval,CovProbReq, pch='+',col='green',cex=1.5)
    if(LCMRLResultFlag==1)
    {
      legend(1.5*LCMRLval,CovProbReq,
             c(paste('LCMRL =',sprintf("%.3f",LCMRLval),strUnits),
               paste("Qual Lim:",RecoveryRange), paste('Coverage Prob:',CovProbReq)),
             bty='n')
    } else
    {
      op <- par(bg="grey81")
      legend(1.5*LCMRLval,CovProbReq,
             c(paste('LCMRL =',sprintf("%.3f",LCMRLval),strUnits),
               paste("Qual Lim:",RecoveryRange), paste('Coverage Prob:',CovProbReq) ))
      par(op)
      legend("center",legend="LCMRL is Below Lowest Non-Zero SL",text.col=2,bty='n')
    }
    
    ## DIS 11/25/2020 - Annotate plots when def par not used
    if(defParFlag==T){
      legend("bottomright",legend='Default parameters used',text.col='blue',bty='n')
    }else{
      legend("bottomright",legend='Default parameters NOT used',text.col='red',bty='n')
    }
    
    # plot LCMRL, DL, response model, prediction limits and quality limits
    if(is.null(labnum))
    {
      plot(SpikeConc,MeasConc, main=paste(AnalName,"- LCMRL Plot"),
           xlab=paste("True Concentration"," (",strUnits,")"),
           ylab=paste("Measured Concentration"," (",strUnits,")"),
           col='blue',pch="o",
           ylim=c(0,1.05*upQL*maxS),xlim=c(0,maxS))
    } else
    {
      plot(SpikeConc,MeasConc, main=paste(AnalName,"Lab",
                                          labnum,"\n","LCMRL Plot"),
           xlab=paste("True Concentration"," (",strUnits,")"),
           ylab=paste("Measured Concentration"," (",strUnits,")"),
           col='blue',pch="o",
           ylim=c(0,1.05*upQL*maxS),xlim=c(0,maxS))
    }
    points(LCMRLval,LCMRLval, pch='+',cex=1.5, col='green')
    points(DLval,DLval, pch='x',cex=1,col='green' )
    lines(xpts,mu)
    lines(c(xlow,maxS),c(xlow,maxS)*lowQL, lty=2,col='red')
    lines(c(xlow,maxS),c(xlow,maxS)*upQL, lty=2, col='red')
    lines(xpts,lowPred,lty=3,col='blue')
    lines(xpts,upPred,lty=3,col='blue')
    topleft <- par()$usr[c(1,4)]
    if(LCMRLResultFlag==1)
    {
      legend(topleft[1],topleft[2],
             c('Data',paste('LCMRL =',sprintf("%.3f",LCMRLval),strUnits),
               paste('Hubaux-Vos DL',sprintf("%.3f",DLval),strUnits),
               paste(RecoveryRange, "Recovery"),'Lower/Upper Prediction Limits'),
             col=c('blue','green','green','red','blue'),
             pch=c("o","+","x","",""),lty=c(0,0,0,2,3) )
    } else
    {
      op <- par(bg="grey81")
      legend(topleft[1],topleft[2],
             c('Data',paste('LCMRL =',sprintf("%.3f",LCMRLval),strUnits),
               paste('Hubaux-Vos DL',sprintf("%.3f",DLval),strUnits),
               paste(RecoveryRange, "Recovery"),'Lower/Upper Prediction Limits'),
             col=c('blue','green','green','red','blue'),
             pch=c("o","+","x","",""),lty=c(0,0,0,2,3))
      par(op)
      legend("center",legend='LCRML is Below Lowest Non-Zero SL',text.col=2,bty='n')
    }
    ## DIS 11/25/2020 - Annotate plots when def par not used
    if(defParFlag==T){
      legend("bottomright",legend='Default parameters used',text.col='blue',bty='n')
    }else{
      legend("bottomright",legend='Default parameters NOT used',text.col='red',bty='n')
    }
    par(ask=FALSE)
  }
  wts <- cbind(x,y,robWts)
  dimnames(wts)[[2]] <-  c("SL","Measurement","RobWts")
  dat.tmp <-list(LCMRLval,DLval,CLval,
                 LCMRLResultFlag,LCMRLResultMessage,HVResultFlag,
                 HVResultMessage,MeanFnPar,VarFnPar,MSEFnPar,defParFlag)
  names(dat.tmp) <- list('LCMRLval','DLval','CLval',
                         'LCMRLResultFlag','LCMRLResultMessage','HVResultFlag','HVResultMessage',
                         'MeanFnPar','VarFnPar','MSEFnPar','defParFlag')
  return(dat.tmp)
}
# -------------------------End RobLCMRL------------------------------
####################################################################

####################################################################
# ---------------------Start RobRepVar ---------------------------------
RobRepVar <- function (X,Y,cc=9,k=1,aPwts)
  
  # computes replicate variances at various spiking levels,
  # degrees of freedom and weights for modeling
  #
  # ----------------Outputs-------------------------------------
#
# SpikeLevels = vector of spiking levels with 2 or more results
# RepVars = vector of computed replicate variance at each spiking level
# RepVarDoF = vector of degrees of freedom for each element of RepVars
# RepVarWt = vector of weights for modeling mean-variance function
#
# ----------------Inputs-------------------------------------
#
# X = vector of spiked concentrations
# Y = vector of measured concentrations
# c= tuning constant for biweight
# k = threshold for Huber estimator
# aPwys = normalized Bayesian Weights for MRL calculations#
# ----------------Start code---------------------------------
#
{
  #print("#### In RobRepVar")
  tol12 <-1e-12
  # get unique values of X & counts
  ST <- cbind(as.numeric(names(table(X))),table(X))
  # only retain those for which count > 1
  SpkTmp <- ST[ST[,2]>1,c(1,2)]
  # first column is spiking level
  # second column is count; DoF is count - 1
  SL <- SpkTmp[,1]
  # number of spiking levels
  nLs <- length(SL)
  RVars <- rep(0,nLs)
  RLoc <- RVars
  RWt <- vector("list",nLs)
  RVarDoF <- vector('numeric',length(SL))
  # compute replicate variances and their associated weights
  for(i in 1:nLs)
  {
    #print(paste("SpikeLevel:",i))
    yi <- Y[ abs(X-SL[i]) < tol12]
    aPwtsi <-aPwts[abs(X-SL[i]) < tol12]
    if( var(yi) < tol12 )
    {
      ni <- length(yi)
      RLoc[i] <- yi[1]
      RVars[i] <- 0
      RWt[[i]] <- rep(1,ni)/ni
      RWt[[i]] <- RWt[[i]]*aPwtsi
      RWt[[i]] <- RWt[[i]]/sum(RWt[[i]])
      RVarDoF[i] <- ni*(1-sum(RWt[[i]]^2)) # will be (ni-1) if aPwts are all 1
      #print(c(yi,aPwtsi,ni,RLoc[i],RVars[i],RWt[[i]],RVarDoF[i]))
    } else
    {
      zz <- roblocvar4(yi,cc,k,0,aPwtsi)
      RLoc[i] <-  zz[[1]]
      RVars[i] <- zz[[2]]
      RWt[[i]] <- zz[[3]]
      RVarDoF[i] <- zz[[4]]
      #print(c(yi,aPwtsi,RLoc[i],RVars[i],RWt[[i]],RVarDoF[i]))
    }
  }
  return(list(SL, RVars, RLoc, RWt, RVarDoF, nLs))
}
# -------------------------End RobRepVar----------------------------
####################################################################

####################################################################
# ---------------------Start roblocvar4 ----------------------------
roblocvar4 <- function(XX, cc=9, k=1, convtype=0,Pwts=rep(1,length(XX)))
{
  # roblocvar computes M-estimators of location and also returns weight vector
  #
  # ----------------Inputs-------------------------------------
  #
  # XX = numeric data vector
  # cc = parameter for Bi-weight
  # k = parameter for Huber weight
  #
  # ---------------Outputs-------------------------------------
  #
  # rloc - M-estimator of location
  # rvar - M-estimator of scale
  # rwts - vector of M-estimator of location weights at convergence
  # nw -   weighted number of observations :(nw-1) is dgrees of freedom
  # IsError = Error flag (0-1)
  # Err = Matlab error structure
  #
  # ----------------Start main code---------------------------------
  #
  # initialize variables
  #
  ##print("In roblocvar4")
  ##print(paste("ConvType:",convtype))
  ##print(paste("XX:",XX))
  ##print(paste("aPwts:",Pwts))
  tol <- 1e-4
  maxsteps <- 10
  nsteps <- 0
  
  # use modified Hodges-Lehmann estimator for initial location estimate
  # and Average Deviation from HL location estimate
  
  n <- length(XX)
  m <- n*(n-1)/2
  
  pair_means <- rep(0,m)
  i <- 0
  for (rowi in 1:(n-1))
  {
    for ( colj in (rowi+1):n )
    {
      i <- i+1
      pair_means[i] <- (XX[rowi] + XX[colj])/2
    }
  }
  
  rloc <- median(c(pair_means, median(XX))) # mod. Hodges-Lehmann est
  scal <- 1.4826*mean(abs(XX-rloc))
  ##print(paste("intial.roloc:",rloc))
  ##print(paste("intial.scal:",scal))
  
  # compute Huber(1.0) M-estimate of location and associated weights
  rl_old <- rloc
  delta <- 1
  while ((delta > tol) && (nsteps <= maxsteps))
  {
    ##print("..In Huber while loop")
    rwtsH <- HuberWt(XX,rloc,scal,k)
    ##print(paste("Huber Wt",rwtsH))
    rwtsH <- BlendWts(Pwts,rwtsH)
    ##print(paste("Blend Wt",rwtsH))
    rloc <- sum(rwtsH*XX)
    if(convtype == 0)
    {
      if(rl_old != 0)
      {
        delta <- try(abs((rl_old - rloc)/rl_old),silent==TRUE)
        #if(class(delta)=="try-error" ) {delta <- 0 }
      }
    }else
    {
      delta <- try(abs((rl_old - rloc)/scal),silent==TRUE)
      #if(class(delta)=="try-error" ) {delta <- 0 }
    }
    nsteps <- nsteps + 1
    rl_old <- rloc
    ##print(paste("delta:",delta,"nsteps",nsteps))
  }
  nw <- n*(1-sum(rwtsH*rwtsH))
  rvar <- (n/nw)*sum(rwtsH*(XX-rloc)^2)
  scal <- sqrt(rvar)
  
  #compute Biweight(9) M-estimate of location and associated weights
  rl_old <- rloc
  delta <- 1
  nsteps <- 0
  while (delta > tol && nsteps <= maxsteps)
  {
    rwtsBW <- BisquareWt(XX,rloc,scal,cc)
    rwtsBW <- BlendWts(Pwts,rwtsBW)
    rloc <- sum(rwtsBW*XX)
    if(convtype == 0)
    {
      if( rl_old != 0) {delta <- try(abs((rl_old - rloc)/rl_old),silent=TRUE)}
      if(class(delta)=="try-error" ) {delta <- 0 }
    } else
    {
      delta <- try(abs((rl_old - rloc)/scal),silent=TRUE)
      if(class(delta)=="try-error" ) {delta <- 0 }
    }
    if(is.nan(delta)) { delta <- 0}
    nsteps <- nsteps+1
    rl_old <- rloc
  }
  
  # average weights from Huber(1.0) and biweight(9) estimates
  # compute robust weighted mean and variance with the average weights
  rloc <- sum(rwtsBW*XX)
  nw <- n*(1-sum(rwtsBW*rwtsBW))
  rvar <- (n/nw)*sum(rwtsBW*(XX-rloc)^2)
  return(list(rloc,rvar,rwtsBW,nw))
}

# -----------------------End roblocvar4 --------------------------------
#######################################################################


#######################################################################
# ---------------------Start HuberWt ----------------------------------

HuberWt <- function(x,m,s,k)
{
  u <- (x-m)/s
  nu <- length(u)
  tu <- (abs(u) <= k)   # k=1
  rwts <- tu
  for(i in 1:nu)
  {
    if(tu[i] == 0) { rwts[i] <- k/abs(u[i]) }
  }
  return(rwts/sum(rwts))
}

# -----------------------End HuberWt -----------------------------------
#######################################################################

#######################################################################
# ---------------------BlendWts ------------------------------------
BlendWts <- function(wt1,wt2)
{
  wt <- wt1*wt2
  wt <- wt/sum(wt)
  return(wt)
}
# -----------------------End BlendWts ---------------------------------
#######################################################################

#######################################################################
# ---------------------Start BisquareWt -------------------------------
BisquareWt <- function(x,m,scal,cc)
{
  u <- (x - m)/(cc*scal)   #c=9  tunig constant
  tu <- (abs(u)<=1)
  rwts <- ((1-u^2)^2)*tu
  rwts <- rwts/sum(rwts)
  return(rwts)
}
# -----------------------End BisquareWt -------------------------------
#######################################################################

#######################################################################
# ---------------------Start w.var ------------------------------------

w.var <- function(xx,wts)
{
  n <- length(xx)
  normwts <- wts/sum(wts)
  m <- sum(normwts*xx)
  vx <- sum(normwts * (xx - m)^2)/(1-sum(normwts*normwts))
  return(vx)
}

# -----------------------End w.var -----------------------------------
#######################################################################

#######################################################################
# -----------------------Start VarFn ----------------------------------

VarFn <- function (xv,VFnP )
{
  epsilon <- 1
  xv <- xv*(xv > 0)
  switch(EXPR =VFnP$type,
         power = {v <-pmax((VFnP$b * xv^VFnP$c),rep(VFnP$minVar,length(xv)))},
         constant.power = {v <- VFnP$a + VFnP$b*xv^VFnP$c },
         constant = { v <- VFnP$a * rep(1,length(xv)) }
  )
  return(v)
}

# -----------------------End VarFn -----------------------------------
#######################################################################

#######################################################################
# ---------------------Start MeanFn -----------------------------------

MeanFn <- function(xm,MFP)
{
  switch(MFP$type,
         'linear'=
           {mu <- MFP$a + MFP$b*xm},
         'quadratic'=
           { mu <- MFP$a + MFP$b*xm + MFP$c*xm^2},
         'cubic'=
           {mu <-MFP$a + MFP$b*xm + MFP$c*xm^2 + MFP$d*xm^3})
  # do not allow a negative mean response
  minv <- max(0,MFP$a)
  mu<- pmax(rep(minv,length(mu)),mu)
  return(mu)
}

# -----------------------End MeanFn -----------------------------------
#######################################################################

#######################################################################
# -------------------------Start VarMod------------------------------
VarMod<- function (SL, RV, RVDF)
  
  # VarModdev function
  #
  # computes Gamma nl model for replicate variance at various spiking
  # levels
  #
  # ----------------Inputs-------------------------------------
#
# SpikeLevels = vector of spiking levels with 2 or more results
# RepVars = vector of computed replicate variance at each spiking level
# RepVarDoF = vector of degrees of freedom for each element of RepVars
#
# ---------------Outputs-------------------------------------
#
# VFnP - structure for error variance model, type and parameters
# ------------------------------------------------------------
#
{
  maxC <- 2
  VFnP <- list("",NaN,NaN,NaN,NaN,NaN)
  names(VFnP) <- list("type","a","b","c","DoF","minVar")
  nL <- length(SL)
  DoF <- sum(RVDF)
  
  nL <- length(SL)
  DoF <- sum(RVDF)
  
  # Estimate initial values for b and c using log-scale regression
  # make design matrix omiting first spiking level
  lBC<-lm(log(RV[2:nL])~log(SL[2:nL]),weights=RVDF[2:nL])
  
  # estimate initial values for a, b and c
  ndx <- 1:floor((nL/2)-1)
  A <- max(sum(RV[ndx]*RVDF[ndx])/sum(RVDF[ndx]),1e-8)
  B <- exp(lBC$coefficients[1])
  CC <-min(max(0, lBC$coefficients[2]),maxC)
  
  newCoef <- OptABC(A,B,CC,SL,RV,RVDF)
  A <- newCoef[1]; names(A) <- 'constant'
  B <- newCoef[2]; names(B) <- 'slope'
  CC <- newCoef[3]; names(CC) <- 'power'
  
  if( B <= 0 || CC <= 1e-2 || (B*max(SL)^CC < 0.10*A))
  {
    VFnP$type<-'constant'
    VFnP$a <- mean(RV)
    VFnP$b <- 0
    VFnP$c <- 0
    VFnP$minVar <- A
    VFnP$minVar <- VFnP$a
    VFnP$DoF <- DoF
  }else
  {
    if ( A < (1e-6)*mean(RV))
    {
      VFnP$type <- 'power'
      VFnP$a <- 0
      VFnP$b <- B
      VFnP$c <- CC
      VFnP$minVar <- mean(RV[1:2])
      VFnP$DoF <- DoF - 2
    } else
    {
      VFnP$type <- 'constant.power'
      VFnP$a <- A
      VFnP$b <- B
      VFnP$c <- CC
      VFnP$minVar <- A
      VFnP$DoF <- DoF - 3
    }
  }
  return(VFnP)
}

# -------------------------End VarMod------------------------------
#######################################################################

#######################################################################
#-------------------------Start VfnLoss------------------------------
#
VfnLoss <-function(x,S,V,DF)
{
  maxC <- 2
  BigLoss <- 1e12
  d <- rep(0,length(S))
  e <- d
  for(i in 1:length(S))
  {
    d[i] <- x[1] + x[2]*S[i]^x[3]
    ifelse(d[i] > 0,e[i] <- DF[i]*((V[i]-d[i])^2)/d[i], e[i] <-0)
  }
  loss <- sum(e)
  # ensure parameters in acceptable ranges
  if( x[1] < 1e-08 || x[2] < 0 || x[3] <0 || x[3] > maxC )
  {
    loss <- BigLoss
  }
  return(loss)
}
#
# -------------------------End VfnLoss------------------------------
#######################################################################

#######################################################################
# -------------------------Start OptABC------------------------------
OptABC <-function (A,B,CC,SL,RV,RVDF)
{
  
  # initialize variables
  maxC <- 2
  delta <- -1
  maxiter <- 5
  eps <- 1e-4
  
  x <-c(A,B,CC)
  rslt <- optim(x,VfnLoss,control=list(abstol=1e-16,reltol=1e-16,maxit=10000),S=SL,V=RV,DF=RVDF)
  fold <- rslt$value
  iter <- 1
  
  while ( (delta <= -eps ) && (iter < maxiter) )
  {
    rslt <- optim(rslt[[1]],VfnLoss,control=list(abstol=1e-16,reltol=1e-16,maxit=10000),S=SL,V=RV,DF=RVDF)
    delta <- (rslt$value - fold)/rslt$value
    fold <- rslt$value
    iter <- iter + 1
  }
  
  A <- rslt[[1]][1]
  if (A < 0 ) A <- 0
  B <- rslt[[1]][2]
  if (B < 0) B <- 0
  CC <- rslt[[1]][3]
  if (CC < 0 ) CC <- 0
  if (CC > maxC)  CC <- maxC
  return(c(A,B,CC))
}
#
# -------------------------End OptABC------------------------------
#######################################################################

#######################################################################
#-----------------------Start IRLS ----------------------------------

IRLS <- function(xx,yy,VFnP,Wts,RNNR,theta,maxIter,grphs=1,LN=NULL,BW)
  # WLS computes Iteratively Reweighted Least Squares regressions estimates
  # covB using variance and MSE function models
  #
  # ----------------Inputs-------------------------------------
#
# x = column vector of Spiking concentrations
# y = column vector of Measured response concentrations
# VFPar = structure of parameters for variance function fit in VarModdev
# initWts = vector of weights from robust location-scale estmation
# RNNR = require mean function to be non-negative over range
# theta = tolerance for convergence
# maxIter = maximum allowed number of iterations
#
# ----------------Outputs-------------------------------------
#
# MeanFnPar = structure of parameters for mean concentration function
# MSEfnPar = structure of parameters for conditional MSE function
# pred = vector of predictions corresponding to input vector x
# resids = vector of raw residuals
# residPearson = vector of Pearson residuals
# S_StdRes = std dev of standardized (by variance function) residuals
# IsError = error flag
# Err = error messsage structure
#
# ----------------Start code---------------------------------
#
# initialize variables
#
{
  k <- 1   # threshold for Huber estimator
  cc <- 9  # initial tuing constant for biweight estimator
  converged <- 1
  
  
  #print(paste("###### start IRLS"))
  #print(paste("########### cc =",cc))
  ############
  
  n <- length(xx) # number of observatons
  MFnP <- list("",0,0,0,0,0,0)
  names(MFnP) <- list("type","a","b","c","d","npar","DoF")
  MSEFnP <-VFnP
  
  # make design matrices for linear, quadratic, cubic & quartic models
  DX <- cbind(xx)
  DX2 <- cbind(DX,xx^2)
  DX3 <- cbind(DX2,xx^3)
  DX4 <- cbind(DX3,xx^4)
  if(RNNR ==1)
  {
    xmx <- max(xx)
    xgrid <- seq(0,xmx,length.out = 100)
  }
  # compute initial 1-step BW w-estimator using WLS for linear model
  # start with initial WLS estimate
  
  # initial 1-step BW w-estimator using WLS
  oldMSEfnPar1 <- VFnP  # intial value for MSEfnPar
  oldB1 <- lm(yy~xx,weights = Wts)$coefficients # initial seed est. for WLS
  oldB1[is.na(oldB1)] <- 0
  #[oldB1,oldseB1,oldmse1,oldcovB1,oldp1,pred] = ...
  #  compWLS(xx,yy,VFnP,oldMSEfnPar1,oldB1,cc,ReqNonNegResponse);
  # compWLS returns a list:
  #     [[1]] with an lm.wfit object
  #     {[2]] a numeric giving the residual mean square error of the fit
  #     [[3]] a numeric p giving the number of fit parameters
  
  wls.tmp <- compWLS(xx,DX,yy,VFnP,oldMSEfnPar1,oldB1,cc,RNNR,BW)
  old.mean.model.1 <- wls.tmp[[1]]
  oldB1 <-wls.tmp[[4]]
  oldB1[is.na(oldB1)] <- 0
  #oldseB1 <- summary(old.mean.model.1 )$coefficients[,2]
  oldmse1 <-  wls.tmp[[2]]
  #oldcovB1 <- summary(old.mean.model.1 )$cov
  oldp1 <- wls.tmp[[3]]
  resids <- yy - old.mean.model.1$fitted	# compute raw residuals
  oldnw1 <- wls.tmp[[5]]
  #compute MSE fn
  # compMSE returns a list with MSEFnPar, cMSE estimates, cMSE Spiking Levels
  #         the MSE model object
  mse.t <- compMSE(xx,resids,cc,k,VFnP,BW)
  oldMSEfnPar1 <- mse.t[[1]]
  oldcMSE1 <- mse.t[[2]]
  cmseSL <- mse.t[[3]]
  
  # compute initial 1-step BW w-estimator using WLS for quadratic model
  # start with inital WLS estimate
  oldMSEfnPar2 <- oldMSEfnPar1 # use MSE fn from linear as initial value
  oldB2 <- lm(yy~DX2,weights = Wts)$coefficients # initial seed est. for WLS
  oldB2[is.na(oldB2)] <- 0
  # initial 1-step BW w-estimator using WLS
  #[oldB2,oldseB2,oldmse2,oldcovB2,oldp2,pred] =  ...
  # compWLS(x,DX2,y,VarFnPar,oldMSEfnPar2,oldB2,c,ReqNonNegResponse);
  wls.tmp <- compWLS(xx,DX2,yy,VFnP,oldMSEfnPar2,oldB2,cc,RNNR,BW)
  old.mean.model.2 <- wls.tmp[[1]]
  oldB2 <-wls.tmp[[4]]
  oldB2[is.na(oldB2)] <- 0
  #oldseB2 <- summary(old.mean.model.2 )$coefficients[,2]
  oldmse2 <-  wls.tmp[[2]]
  #oldcovB2 <- summary(old.mean.model.2)$cov
  oldp2 <- wls.tmp[[3]]
  resids <- yy - old.mean.model.2$fitted;	# compute raw residuals
  oldnw2 <- wls.tmp[[5]]
  mse.t <- compMSE(xx,resids,cc,k,oldMSEfnPar1,BW); #compute MSE fn
  oldMSEfnPar2 <- mse.t[[1]]
  oldcMSE2 <- mse.t[[2]]
  
  # compute initial 1-step BW w-estimator using WLS for cubic model
  # start with inital WLS estimate
  oldMSEfnPar3 <- oldMSEfnPar2 # use MSE fn from linear as initial value
  oldB3 <- lm(yy~DX3,weights = Wts)$coefficients # initial seed est. for WLS
  oldB3[is.na(oldB3)] <- 0
  # initial 1-step BW w-estimator using WLS
  #[oldB3,oldseB3,oldmse3,oldcovB3,oldp3,pred] = ...
  #  compWLS(x,DX3,y,VarFnPar,oldMSEfnPar3,oldB3,c,ReqNonNegResponse);
  wls.tmp <- compWLS(xx,DX3,yy,VFnP,oldMSEfnPar3,oldB3,cc,RNNR,BW)
  old.mean.model.3 <- wls.tmp[[1]]
  oldB3 <-wls.tmp[[4]]
  oldB3[is.na(oldB3)] <- 0
  #oldseB3 <- summary(old.mean.model.3 )$coefficients[,2]
  oldmse3 <-  wls.tmp[[2]]
  #oldcovB3 <- summary(old.mean.model.3)$cov
  oldp3 <- wls.tmp[[3]]
  resids <- yy - old.mean.model.3$fitted	# compute raw residuals
  oldnw3 <- wls.tmp[[5]]
  mse.t <- compMSE(xx,resids,cc,k,oldMSEfnPar2,BW); #compute MSE fn
  oldMSEfnPar3 <- mse.t[[1]]
  oldcMSE3 <- mse.t[[2]]
  
  #print("####### end of first WLS call")
  #print(t(DX3))
  #print(oldB3)
  
  # compute initial 1-step BW w-estimator using WLS for quadratic model
  # start with inital WLS estimate
  oldMSEfnPar4 <- oldMSEfnPar3 # use MSE fn from linear as initial value
  oldB4 <- lm(yy~DX4,weights = Wts)$coefficients # initial seed est. for WLS
  oldB4[is.na(oldB4)] <- 0
  # initial 1-step BW w-estimator using WLS
  #[oldB4,oldseB4,oldmse4] = ...
  #  compWLS(x,DX4,y,VarFnPar,oldMSEfnPar4,oldB4,c,ReqNonNegResponse);
  wls.tmp <- compWLS(xx,DX4,yy,VFnP,oldMSEfnPar2,oldB4,cc,RNNR,BW)
  old.mean.model.4 <- wls.tmp[[1]]
  oldB4 <-wls.tmp[[4]]
  oldB4[is.na(oldB4)] <- 0
  #oldseB4 <- summary(old.mean.model.4 )$coefficients[,2]
  oldmse4 <-  wls.tmp[[2]]
  #oldcovB4 <- summary(old.mean.model.4)$cov
  oldp4 <- wls.tmp[[3]]
  # finished initial 1-step BW w-estimators (c=9)
  
  
  # initially try IRLS with c=9
  # if any model fails to converge, go to c=9 for all models
  cc <- 9; # initial value for Tukey's biweight (BW) parameter
  
  
  all.irls <- compAllIRLS(xx,DX,DX2,DX3,DX4,yy,VFnP,oldMSEfnPar1,oldB1,
                          oldMSEfnPar2,oldB2,oldMSEfnPar3,oldB3,
                          oldMSEfnPar4,oldB4,
                          cc,k,RNNR,theta,maxIter,grphs,LN,BW)
  converged <- all.irls[[1]]
  #print("end of compALLIRLS")
  if( converged==0 )
    # check for convergence of all models
    # if any fail to converge, revert to initial 1-step estimate
  {
    B1<-oldB1
    mse1<-oldmse1
    p1<-oldp1
    MSEfnPar1 <- oldMSEfnPar1
    cMSE1 <- oldcMSE1
    nw1 <- oldnw1
    B2<-oldB2
    mse2<-oldmse2
    p2<-oldp2
    MSEfnPar2 <- oldMSEfnPar2
    cMSE2 <- oldcMSE2
    nw2 <- oldnw2
    B3<-oldB3
    mse3<-oldmse3
    p3<-oldp3
    MSEfnPar3 <- oldMSEfnPar3
    cMSE3 <- oldcMSE3
    nw3 <- oldnw3
    mse4<-oldmse4
    mean.model.1 <- old.mean.model.1
    mean.model.2 <- old.mean.model.2
    mean.model.3 <- old.mean.model.3
    mean.model.4 <- old.mean.model.4
    #cmse.model.4 <- old.cmse.model.4
    
  } else
  {
    B1<-all.irls[[2]]
    mse1<-all.irls[[3]]
    p1<-all.irls[[4]]
    MSEfnPar1 <- all.irls[[5]]
    cMSE1 <- all.irls[[6]]
    nw1 <- all.irls[[23]]
    B2<-all.irls[[7]]
    mse2<-all.irls[[8]]
    p2<-all.irls[[9]]
    MSEfnPar2 <- all.irls[[10]]
    cMSE2 <- all.irls[[11]]
    nw2 <- all.irls[[24]]
    B3<-all.irls[[12]]
    mse3<-all.irls[[13]]
    p3<-all.irls[[14]]
    MSEfnPar3 <- all.irls[[15]]
    cMSE3 <- all.irls[[16]]
    nw3 <- all.irls[[25]]
    mse4<-all.irls[[18]]
    mean.model.1 <- all.irls[[19]]
    mean.model.2 <- all.irls[[20]]
    mean.model.3 <- all.irls[[21]]
    mean.model.4 <- all.irls[[22]]
  }
  
  # compute DoF and RSS for linear through cubic models
  d1 <- nw1 - p1
  RSS1 <- mse1*d1
  d2 <- nw2 - p2
  RSS2 <- mse2*d2
  d3 <- nw3 - p3
  RSS3 <- mse3*d3
  
  # compute Cp values for different models
  Cp1 <- RSS1/mse4 - (d1-p1)
  Cp2 <- RSS2/mse4 - (d2-p2)
  Cp3 <- RSS3/mse4 - (d3-p3)
  Cp <- c(Cp1,Cp2,Cp3)
  
  minCp <- min(Cp)
  ndx <- 1:3
  minCpndx <- ndx[Cp == minCp]
  
  # set values to return based on best fitting model
  switch (minCpndx,
          { # case 1 % linear
            pred <- mean.model.1$fitted
            MFnP$type <- 'linear'
            MFnP$a <- B1[1]
            MFnP$b <- B1[2]
            MFnP$npar <- p1
            MFnP$DoF <- d1
            MSEFnP <- MSEfnPar1
            cMSE <- oldcMSE1
            M.model <- mean.model.1
          },
          { #case 2 % quadratic
            pred <- mean.model.2$fitted
            MFnP$type <- 'quadratic'
            MFnP$a <- B2[1]
            MFnP$b <- B2[2]
            MFnP$c <- B2[3]
            MFnP$npar <- p2
            MFnP$DoF <- d2
            MSEFnP <- MSEfnPar2
            cMSE <- oldcMSE2
            M.model <- mean.model.2
          },
          { # case 3 % cubic
            pred <- mean.model.3$fitted
            MFnP$type <- 'cubic'
            MFnP$a <- B3[1]
            MFnP$b <- B3[2]
            MFnP$c <- B3[3]
            MFnP$d <- B3[4]
            MFnP$npar <- p3
            MFnP$DoF <- d3
            MSEFnP <- MSEfnPar3
            cMSE <- oldcMSE3
            M.model <- mean.model.3
          }
  )
  
  resids <- yy - pred;
  vf <- VarFn(xx,MSEFnP) # variances
  wt <- Wts/vf
  wt <- wt/sum(wt)
  wtm <- sum(yy*wt)/sum(wt)
  dev <- yy - wtm
  SSrat <- sum(wt*resids^2)/sum(wt*dev^2)
  R2adj <- 1 - SSrat*(MFnP$DoF+MFnP$npar-1)/MFnP$DoF
  StdRes <- resids/sqrt(vf)
  S_StdRes <- sd(StdRes)
  residPearson <- StdRes/S_StdRes
  #print("########end IRLS")
  return(list(MFnP,MSEFnP,R2adj,Cp,pred,resids,residPearson,S_StdRes,cMSE,
              cmseSL,M.model))
}
#
# -------------------------End IRLS code------------------------------
#######################################################################

#######################################################################
# -------------------------Start compAllIRLS------------------------------
#
compAllIRLS <- function(x,DX,DX2,DX3,DX4,y,VFnP,
                        oldMSEfnPar1,oldB1, oldMSEfnPar2,oldB2,
                        oldMSEfnPar3,oldB3,oldMSEfnPar4,oldB4,
                        cc,k,RNNR,theta,maxIter,grphs,LN,BW)
{
  converged <- 1
  
  
  # create grid to test for negative values
  if( RNNR==1 )
  {
    xmx <- max(x)
    xgrid <- seq(0,xmx,length.out=100)
    DXgrid <- cbind(rep(1,100),xgrid)
  }
  
  # compute IRLS for linear model
  irls.tmp <- compIRLS(x,DX,y,VFnP,oldMSEfnPar1,oldB1,cc,k,RNNR,
                       theta,maxIter,grphs,LN,BW)
  B1 <- irls.tmp[[1]]
  #seB1 <- irls.tmp[[2]]
  mse1 <- irls.tmp[[2]]
  #covB1 <- irls.tmp[[4]]
  p1 <- irls.tmp[[3]]
  MSEfnPar1 <- irls.tmp[[4]]
  cMSE1 <- irls.tmp[[5]]
  cmseSpikeLevels <- irls.tmp[[6]]
  nw1 <- irls.tmp[[9]]
  converged <- irls.tmp[[7]]
  m.model.1 <- irls.tmp[[8]]
  
  if (converged == 0) { return(list(converged)) }
  
  # compute IRLS for quadratic model
  irls.tmp <- compIRLS(x,DX2,y,VFnP,oldMSEfnPar2,oldB2,cc,k,RNNR,
                       theta,maxIter,grphs,LN,BW)
  B2 <- irls.tmp[[1]]
  #seB2 <- irls.tmp[[2]]
  mse2 <- irls.tmp[[2]]
  #covB2 <- irls.tmp[[4]]
  p2 <- irls.tmp[[3]]
  MSEfnPar2 <- irls.tmp[[4]]
  cMSE2 <- irls.tmp[[5]]
  cmseSpikeLevels <- irls.tmp[[6]]
  nw2 <- irls.tmp[[9]]
  converged <- irls.tmp[[7]]
  m.model.2 <- irls.tmp[[8]]
  
  if (converged == 0) {return(list(converged)) }
  
  irls.tmp <- compIRLS(x,DX3,y,VFnP,oldMSEfnPar3,oldB3,cc,k,RNNR,
                       theta,maxIter,grphs,LN,BW)
  B3 <- irls.tmp[[1]]
  #seB3 <- irls.tmp[[2]]
  mse3 <- irls.tmp[[2]]
  #covB3 <- irls.tmp[[4]]
  p3 <- irls.tmp[[3]]
  MSEfnPar3 <- irls.tmp[[4]]
  cMSE3 <- irls.tmp[[5]]
  cmseSpikeLevels <- irls.tmp[[6]]
  nw3 <- irls.tmp[[9]]
  converged <- irls.tmp[[7]]
  m.model.3 <- irls.tmp[[8]]
  
  if( converged == 0 ){  return(list(converged))  }
  
  # compute IRLS for quadratic model
  irls.tmp <- compIRLS(x,DX4,y,VFnP,oldMSEfnPar4,oldB4,cc,k,RNNR,
                       theta,maxIter,grphs,LN,BW)
  B4 <- irls.tmp[[1]]
  #seB4 <- irls.tmp[[2]]
  mse4 <- irls.tmp[[2]]
  converged <- irls.tmp[[7]]
  m.model.4 <- irls.tmp[[8]]
  
  if( converged == 0 ) {return(list(converged)) }
  #print("## end compAllIRLS")
  # if convergence for all models return full list
  return(list( converged,B1,mse1,p1,MSEfnPar1,cMSE1,    #6
               B2,mse2,p2,MSEfnPar2,cMSE2,              #11
               B3,mse3,p3,MSEfnPar3,cMSE3,              #16
               B4,mse4,                                 #18
               m.model.1,m.model.2,m.model.3,m.model.4, #22
               nw1,nw2,nw3))                            #25
}
#
#-------------------------End compAllIRLS------------------------------
########################################################################

########################################################################
# -------------------------Start compIRLS------------------------------
#
#function [B,seB,mse,covB,p,MSEfnPar,cMSE,cmseSpikeLevels,converged,...
#  IsError,Err] = compIRLS(x,DX,y,VarFnPar,MSEfnPar,B,c,k,...
#  ReqNonNegResponse,theta,maxIter)
compIRLS <- function(xx,DX,yy,VFnP,MSEFnP,B,cc,k,RNNR,theta,maxIter,grphs,LN,BW)
{
  converged <- 1  # initialize converge to 1 meaning convergence is TRUE
  innerEpsilon <- 1
  outerEpsilon <- 1
  innerNumIter <- 0
  outerNumIter <- 0
  
  while( outerEpsilon > theta && outerNumIter < maxIter)
  {
    ooB <- B
    while( innerEpsilon > theta && innerNumIter < maxIter )
    {
      oB <- B
      #[B,seB,mse,covB,p,pred]
      #print("####in loop:")
      #print(t(DX))
      #print(oB)
      wls.tmp <- compWLS(xx,DX,yy,VFnP,MSEFnP,oB,cc,RNNR,BW)
      mean.model <- wls.tmp[[1]]
      B <-wls.tmp[[4]]
      B[is.na(B)] <- 0   # remove possible NAs from oldB from bad fit
      #seB <- summary(mean.model )$coefficients[,2]
      Rmse <-  wls.tmp[[2]]
      #covB <- summary(mean.model)$cov
      p <- wls.tmp[[3]]
      pred <- mean.model$fitted
      nw <- wls.tmp[[5]]
      innerEpsilon <- max(abs(oB - B))
      innerNumIter <- innerNumIter + 1
    }
    resids <- yy - pred # compute raw residuals
    #compute MSE fn
    mse.t <- compMSE(xx,resids,cc,k,MSEFnP,BW); #compute MSE fn
    MSEFnP <- mse.t[[1]]
    cMSE <- mse.t[[2]]
    cmseSL <- mse.t[[3]]
    outerEpsilon <- max(abs(ooB - B))
    outerNumIter <- outerNumIter + 1;
  }
  if(outerNumIter >= maxIter ) {converged <- 0 }
  #print("## end compIRLS")
  return(list(B,Rmse,p,MSEFnP,cMSE,cmseSL,converged,
              mean.model,nw))
}

#
# -------------------------End compIRLS------------------------------
########################################################################

#######################################################################
# -------------------------Start compWLS------------------------------
#
compWLS <-function (x,DX,y,VFnPar,MSEFnP,oldB,cc,RNNR,BW)
{
  
  # get minimum nonzero response
  minNZR <- min(y[y>0])
  
  # compute WLS
  vf <- VarFn(x,MSEFnP)  # variances
  sf <- sqrt(vf) #standard deviations
  pred <- as.vector(cbind(rep(1,length(DX[,1])),DX) %*% oldB)  # compute predicted values
  rwts <- BisquareWt(x,pred,sf,cc)
  rwts <- BlendWts(BW,rwts)
  Wt <-  rwts/vf
  Wt <- Wt/sum(Wt)
  p <- length(DX[1,])+1
  n <- length(DX[,1])
  nw <- n*(1-sum(Wt*Wt)) + 1
  
  #write.csv(Wt,"weights",append=TRUE)
  # [B,seB,mse,covB] = lscov(DX,y,Wt);
  wls.tmp <- lm.wfit(cbind(rep(1,length(DX[,1])),DX),y,Wt)
  B <- wls.tmp$coefficients
  B[is.na(B)] <- 0    # remove possible NAs from oldB from bad fit
  #print("### in compWLS lmfit B")
  #print(B)
  
  #pred <- as.vector(cbind(rep(1,length(x)),DX) %*% B)  #compute predicted values
  resids <- y - wls.tmp$fitted
  RSS <- sum(Wt*resids^2)
  R.mse <- RSS/(nw-p)
  #print(paste("in compWLS B return =",B))
  #print(" end compWLS")
  return(list(wls.tmp,R.mse,p,B,nw))
  
}

# -------------------------End compWLS------------------------------
########################################################################

#######################################################################
# -------------------------Start compMSE------------------------------
#
#function [MSEfnPar,cMSE,cmseSpikeLevels,IsError,Err] = compMSE(X,resids,c,k)
compMSE <- function(X,Resids,cc,k,VFnP,BW)
{
  # compute (conditional) mean squared error (MSE) by spiking level
  ## compute (conditional) mean squared error (MSE) by spiking level
  ## [cMSE,cmseSpikeLevels, nLevels, MSEcnt,IsError, Err] ...
  ##     = robCondMSE(X,resids,c,k)
  cond.mse.tmp <- robCondMSE(X,Resids,cc,k,BW)
  cMSE <- cond.mse.tmp[[1]]
  cmseSL <- cond.mse.tmp[[2]]
  nLevels <- cond.mse.tmp[[3]]
  MSEcnt <- cond.mse.tmp[[4]]
  #print("## in compMSE")
  
  # check for 0 spiking level (method blanks) and remove for replicate
  # variance model calc
  #if( cmseSL[1] == 0)
  #   {
  #   cmseSL <- cmseSL[2:nLevels]
  #   cMSE <- cMSE[2:nLevels]
  #   MSEcnt <- MSEcnt[2:nLevels]
  #   }
  
  # check for 0 values in vector of conditional MSEs
  if(all(cMSE == 0))
  {
    stop('All conditional MSEs are 0. Likely cause is data entry error')
  }
  if( any(cMSE == 0))
  {
    warning(paste('Warning: One or conditional MSEs is 0. Likely causes are:/n',
                  'data entry error or variance damping (due to insufficient significant digits/n',
                  'smoothing or thresholding'))
    VarOK <- cMSE > 0
    cmseSL <- cmseSL[VarOK]
    cMSE <- cMSE[VarOK]
    MSEcnt <- MSEcnt[VarOK]
    nmseLevels <- length(cmseSpikeLevels)
  }
  
  # DoF for conditonal MSE
  cmseDoF <- MSEcnt
  
  # estimate model for (conditional) mean squared error (MSE) by spiking
  # level
  
  mse.tmp <- MseMod(cmseSL,cMSE,cmseDoF,VFnP)
  #print("## end compMSE")
  return(list(mse.tmp,cMSE,cmseSL))
}
#
# -------------------------End compMSE------------------------------
#######################################################################

#######################################################################
# -------------------------start robCondMSE------------------------------
#function [robMSE,SpikeLevels, nLevels, MSEcnt,IsError, Err] ...
#    = robCondMSE(X,resids,c,k)
robCondMSE <- function(X,Resids,cc,k,BW)
{
  # RepVar function
  #
  # computes MSE at various spiking levels,
  # degrees of freedom and weights for modeling
  #
  # ----------------Outputs-------------------------------------
  #
  # robMSE = robust estimates of MSE by spiking level
  # SpikeLevels = vector of spiking levels with 2 or more results
  # nLevels = number of spiking levels
  # MSEcnt = number of residuals per spiking level
  # IsError = Error flag (0-1)
  # Err = Matlab error structure
  #
  # ----------------Inputs-------------------------------------
  #
  # X = vector of spiked concentrations
  # resids = vector of regression residuals from means model
  # c = tuning constant for biweight
  # k = threshold for Huber estimator
  #
  
  # check for 0 variance at spiking level (method blanks with all 0 results)
  # and remove for replicate variance model calc
  if(X[1]==0)
  {
    NZndx <- (X != 0)
    X <- X[NZndx]
    Resids <- Resids[NZndx]
    BW <- BW[NZndx]
  }
  
  # get unique values of X & counts
  STable <- cbind(as.numeric(names(table(X))),table(X))
  # first column is spiking level
  SL <- STable[,1]
  # second column is count; DoF is count
  nw <- STable[,2]
  # number of spiking levels
  nLs <- length(SL)
  robmse <- rep(0,nLs)
  # estimate MSE
  for( i in 1:nLs )
  {
    yi <- Resids[abs(X-SL[i])< 1e-12]
    BWi <- BW[abs(X-SL[i])< 1e-12]
    if (w.var(yi,BWi) <= 1e-12 )
    {
      robmse[i] <- sum(yi*BWi/sum(BWi))^2
    } else
    {
      tmp <- roblocvar4(yi,cc,k,1,BWi)
      robmse[i] <- tmp[[2]] + tmp[[1]]^2
      nw[i] <- tmp[[4]]+1
    }
  }
  return(list(robmse, SL, nLs, nw))
}
# -----------------------End robCondMSE ---------------------------------
#######################################################################

#######################################################################
#-------------------------Start MseMod------------------------------
#
MseMod <- function (SL, RMse, MDF,MsePar)
  #
  # computes Gamma nl model for replicate variance at various spiking
  # levels
  #
  # ----------------Inputs-------------------------------------
#
# SpikeLevels = vector of spiking levels with 2 or more results
# RMse = vector of computed replicate variance at each spiking level
# MDF = vector of degrees of freedom for each element of MSE
# MsePar
# ---------------Outputs-------------------------------------
#
# MseFnPar - structure for error variance model, type and parameters
# IsError = Error flag (0-1)
# Err = Matlab error structure
#

# initialize variables
#
{
  maxC <- 2
  nL <- length(SL)
  DoF <- sum(MDF)
  
  MFnP <- MsePar
  
  # Take initial values for a, b and c from input MsePar
  A <- max(0,MsePar$a)
  B <- MsePar$b
  CC <- min(MsePar$c,maxC)
  
  newCoef <- OptABC(A,B,CC,SL,RMse,MDF)
  
  A <- newCoef[1] ; names(A) <- 'constant'
  B <- newCoef[2] ; names(B) <- 'slope'
  CC <- newCoef[3]; names(CC) <-'power'
  
  if( B <= 0 || CC <= 1e-2 || (B*max(SL)^CC < 0.10*A))
  {
    MFnP$type<-'constant'
    MFnP$a <- mean(RMse)
    MFnP$b <- 0
    MFnP$c <- 0
    MFnP$minVar <- A
    MFnP$minVar <- MFnP$a
    MFnP$DoF <- DoF
  } else
  {
    if ( A < (1e-6)*mean(RMse) )
    {
      MFnP$type <- 'power'
      MFnP$a <- 0
      MFnP$b <- B
      MFnP$c <- CC
      MFnP$minVar <- mean(RMse[1:2])
      MFnP$DoF <- DoF - 2
    } else
    {
      MFnP$type <- 'constant.power'
      MFnP$a <- A
      MFnP$b <- B
      MFnP$c <- CC
      MFnP$minVar <- A
      MFnP$DoF <- DoF - 3
    }
  }
  return(MFnP)
}
#
# -------------------------End MseMod------------------------------
#######################################################################

#######################################################################
# -----------------------Start feq ---------------------------------
feq <- function(x,y,tol)
{
  return(abs(x-y) <= tol)
}
# -----------------------end  feq  ---------------------------------
#######################################################################

#######################################################################
# ---------------------Start GammaPar ---------------------------------
GammaPars <- function(mu, v)
  
  # GammaPars Function
  #
  # Computes the shape and scale parameters of a gamma distribution using the
  # method of moments
  #
  # ----------------Inputs-------------------------------------
#  mu = mean
#  v = variance
#
# ----------------Outputs-------------------------------------
#  A = shape
#  B = scale
#
{
  B <- v/mu
  A <- mu/B
  return(list(A,B))
}
# -----------------------End GammaPar ---------------------------------
#######################################################################

#######################################################################
# -------------------------Start covProb------------------------------

covProb <- function(xc,LQL,UQL,MFP,VFP,MSEFP,CPR,nn,xxbar,ssxx,RNNR)
{
  if( RNNR == 1)
  {
    # assign parameter values for Gamma
    lmm <- MeanFn(xc,MFP)
    lv <- VarFn(xc,MSEFP)*(1+1/nn+((xc-xxbar)^2)/ssxx)
    gpar <-GammaPars(lmm,lv)
    A <- gpar[[1]]
    B <- gpar[[2]]
    # compute coverage probability under Gamma
    cvP <- pgamma(xc*UQL,A, scale=B) - pgamma(xc*LQL,A,scale=B)
  } else
  {
    lmm <- MeanFn(xc,MFP)
    lv <-  VarFn(xc,MSEFP)*(1+1/nn+((xc-xxbar)^2)/ssxx)
    lss <- sqrt(lv)
    DoF <- min(VFP$DoF,MSEFP$DoF)
    #compute coverage probability under Normal
    cvP <- pt((xc*UQL-lmm)/lss,DoF)-pt((xc*LQL-lmm)/lss,DoF)
  }
  return(cvP)
}

# -------------------------End covProb---------------------------------
#######################################################################

#######################################################################
# -------------------------Start GammaEstFn----------------------------

GammaEstFn <-function(xs,LQL,UQL,MFP,VFP,MSEFP,CPR,nn,xxbar,ssxx,RNNR)
  # GammaEstFn function
  #
  # Estimating function for difference between probability content of gamma
  # distribution between two limits and target coverage. Mean and variance
  # are specified by the independent variable x and with specified mean
  # and variance functions.
  #
  # ----------------Outputs-------------------------------------
#
# discrep = difference between probability content of interval
#           and target coverage
#
# ----------------Inputs-------------------------------------
#
# xs = spiking level
# MFP =
# VFP =
# MSEFP =
# mV =
# LQL =
# UQL =
# CovPrReq =
# -----------------------------------------------------------
{
  # get mean and variance
  #print("######## in GammaEstFn")
  #print(xs)
  #print(MFP)
  lmm <- MeanFn(xs,MFP)
  lv <- VarFn(xs,MSEFP)*(1+1/nn+((xs-xxbar)^2)/ssxx )
  if( RNNR==1)
  {
    # assign parameters for Gamma
    gpars <- GammaPars(lmm,lv)
    A <-gpars[[1]]
    B <- gpars[[2]]
    # compute coverage probability discrepancy
    discrep <- pgamma(xs*UQL,A,scale=B) - pgamma(xs*LQL,A,scale=B)- CPR
  } else
  {
    # assign parameters for Normal
    lss <- sqrt(lv)
    DoF <- min(VFP$DoF,MSEFP$DoF)
    #compute coverage probability discrepancy
    discrep <- pt((xs*UQL-lmm)/lss,DoF)- pt((xs*LQL-lmm)/lss,DoF)-CPR
  }
  return(discrep)
}


# -------------------------End GammaEstFn-----------------------------
#######################################################################

#######################################################################
# -------------------------Start srchLCMRL-------------------------------
srchLCMRL <-function (SL,LQL,UQL,MFP,VFP,MSEFP,CPR,nn,xxbar,ssxx,RNNR,LLLCMRL)
{
  # Searches for value of x that sets GammaEstFn value to 0. This is the
  # estimated LCMRL
  #
  # ----------------Outputs-------------------------------------
  #
  # LCMRL = Lowest Concentration Minimum Reporting Limit
  # CovProbMat = matrix with spiking levels and estimated coverage
  #   probabilities for specified quality interval
  #
  # ----------------Inputs ------------------
  #
  # SL = spiking levels
  # LowQL = lower quality limit for recovery of spike
  # UpQL = upper quality limit for recovery of spike
  # CPR = desired probability for acceptable spike recovery
  # MFP = parameters of mean function for response
  # VFP = parameters of variance function for response
  #
  # ----------------Start code---------------------------------
  #
  # get endpoints of spiking interval
  #print("############## in Search LCMRL")
  ResultFlag <- 0
  xmx <- max(SL) #upper end of search interval
  if( LLLCMRL ==0)
  {
    xmn <- min(SL) #tentative lower end of search interval
    
    # ensure that sign of EstFn is negative at lower end of interval
    while(sign(GammaEstFn(xmn,LQL,UQL,MFP,VFP,MSEFP,CPR,nn,xxbar,ssxx,RNNR))>0)
    {
      xmn <- xmn/2
      ResultFlag <- -1
      ResultMessage <- 'LCMRL is below lowest spiking level'
    }
  } else
  {
    xmn <- LLLCMRL
    if( sign(GammaEstFn(xmn,LQL,UQL,MFP,VFP,MSEFP,CPR,nn,xxbar,ssxx,RNNR))>0)
    {
      ResultFlag <- -5
      LCMRL.lst <- list(LLLCMRL,0,0,0)
    }
  }
  xgrid <- seq(xmn,xmx,length.out=100)
  GEFgrid <- rep(0,100)
  
  # compute signs of GammaEstFn on grid over (xmn,xmx)
  
  GEFgrid <- GammaEstFn(xgrid,LQL,UQL,MFP,VFP,MSEFP,
                        CPR,nn,xxbar,ssxx,RNNR)
  # check to see whether LCMRL is above highest spiking level
  if( all(GEFgrid<0) )
  {
    ResultFlag <- -2
    ResultMessage <- 'LCMRL is above highest spiking level'
    LCMRLval <- 0  # explicitly set to 0; test for 0 in srchDL
    # generate points for plot of QC interval coverage
    xp <- xgrid
    yp <- covProb(xp,LQL,UQL,MFP,VFP,MSEFP,CPR,nn,xxbar,ssxx,RNNR)
    CPMat <- c(xp,yp)
    return(list(LCMRLval,CPMat,ResultFlag,ResultMessage))
  }
  
  # hunt for change of sign in GEFgrrid
  ndxu <-match(1,sign(GEFgrid[1:100]))
  if ( ndxu > 2) { ndxl <- ndxu - 2 } else { ndxl <- ndxu - 1 }
  xl <- xgrid[ndxl]
  xu <- xgrid[ndxu]
  
  # check again to see whether LCMRL is above highest spiking level
  if ( !all(GEFgrid[ndxu:100] > 0))
  {
    ResultFlag <- -2
    ResultMessage <- 'LCMRL is above highest spiking level'
    LCMRLval <- 0 # explicitly set to 0; test for 0 in srchDL
    # generate points for plot of QC interval coverage
    xp <- xgrid
    yp <- covProb(xp,LQL,UQL,MFP,VFP,MSEFP,CPR,nn,xxbar,ssxx,RNNR)
    CPMat <- c(xp,yp)
    return(list(LCMRLval,CPMat,ResultFlag,ResultMessage))
  }
  
  #find zero of EStFn; this is the LCMRL
  if( ResultFlag != -5)
  {
    LCMRL.lst <- try(uniroot(GammaEstFn,c(xl,xu),LQL=LQL,UQL=UQL,
                             MFP=MFP,VFP=VFP,MSEFP=MSEFP,CPR=CPR,
                             nn=nn,xxbar=xxbar,ssxx=ssxx,RNNR=RNNR,tol=1e-8))
    
    if( class(LCMRL.lst)[1]=="try-error")
    {
      ResultFlag <- -3
      ResultMessage <- geterrmessage()
    }
  }
  switch( as.character(ResultFlag),
          
          '-5' = {ResultMessage <- 'LCMRL below lowest Spiking Level with all non-zero results: set equal to lowest spiking level with all non-zro results'
          CPMat <- 0},
          '-3' = {ResultMessage <- 'Nonconvergence' },
          '-1' = {ResultMessage <-'Lower spiking level needed to bracket the LCMRL'
          # generate points for plot of QC interval coverage probability
          xp <- 10^seq(log10(xmn),log10(max(SL)),length.out=50)
          yp <- covProb(xp,LQL,UQL,MFP,VFP,MSEFP,CPR,nn,xxbar,ssxx,RNNR)
          CPMat <- cbind(xp,yp)},
          '0'  = {ResultFlag <- 1
          ResultMessage <- 'LCMRL Calculated'
          # generate points for plot of QC interval coverage probability
          xp <- 10^seq(log10(xmn),log10(xmx),length.out=50)
          yp <- covProb(xp,LQL,UQL,MFP,VFP,MSEFP,CPR,nn,xxbar,ssxx,RNNR)
          CPMat <- cbind(xp,yp)}
  )
  #print("############## end Search LCMRL")
  return(list(LCMRL.lst,CPMat,ResultFlag,ResultMessage))
}
#
# -------------------------End srchLCMRL-------------------------------
#######################################################################

#######################################################################
# ---------------------Start HubauxVos --------------------------------
HubauxVos <- function (MFP,VFP,MSEFP,a,b,lcmrlval,sL,RNNR,ZRF)
{
  # function HubauxVos
  #
  # determines regression based detection limit based on modification of
  # approach of Hubaux & Vos
  #
  # ----------------Outputs-------------------------------------
  #
  # DL = detection limit
  # ResultFlag = result flag for HV DL
  # ResultMessage = result message for HV DL
  #     -3 - 'Nonconvergence: ' output.message
  #     -2 - 'PROBLEM: DL appears to be above max spiking level'
  #      0 - not set
  #      1 - 'Valid DL'
  #      2  - 'DL calculated >= LCMRL; set DL = LCMRL'
  # IsError = error flag
  # Err = error messsage structure
  #
  # ----------------Inputs-------------------------------------
  #
  # MeanFnPar = parameter structure for mean response function
  # VarFnPar = parameter structure for variance function of response
  # alpha = probability defining critical response (yc) in HV DL
  # beta = probability defining DL in HV DL--Pr(y <= yc | x = DL) = beta
  #
  # ----------------Start code---------------------------------
  #
  #
  # initialize variables
  #
  #MFP <- MeanFnPar
  #VFP <- VarFnPar
  #MSEFP <- MSEFnPar
  # a <-alpha
  # b <- beta
  ResultFlag <-0
  ResultMessage <- 'General Error in DL determination'
  
  MV <- max(VFP$minVar,MSEFP$minVar)
  stdv <- sqrt(MV)
  # expected meas conc at 0 spiking level
  y0 <- MeanFn(0,MFP)
  # est'd variance at 0 spiking level
  DoF <- min(VFP$DoF,MSEFP$DoF)
  # estimate critical concentration, yc
  if(RNNR == 1)
  {
    if (y0 > 0 )  # assume truncated t if predicted mean is positive
    {
      yc <- y0+stdv*qt(pt(-y0/stdv,DoF)+(1-a)*(1-pt(-y0/stdv,DoF)),DoF)
    } else  # assume half-t distr
    {
      yc <- stdv*qt(1-a/2,DoF)
    }
  } else  # Response can be negative
  {
    yc = y0 + stdv*qt(1-a,DoF) # assume t distribution
  }
  Lc <- yc  # critical level
  srchdl.lst <- srchDL(lcmrlval,yc,sL,MFP,VFP,MSEFP,MV,b,RNNR,ZRF)
  DL <- srchdl.lst[[1]]
  fval <- srchdl.lst[[2]]
  ResultFlag<-srchdl.lst[[3]]
  ResultMessage<-srchdl.lst[[4]]
  return(list(DL,Lc,ResultFlag,ResultMessage))
}

#---------------------End HubauxVos ----------------------------------
#######################################################################

#######################################################################
# ---------------------Start srchDL -----------------------------------
srchDL <- function(lcmrlval,yc,sL,MFP,VFP,MSEFP,MV,b,RNNR,ZRF)
{
  #
  # Searches for value of x that sets DLEstFn value to 0. This is the
  # estimated HVDL
  #
  # ----------------Outputs-------------------------------------
  #
  # DLval = regression based detection limit based on approach of Hubaux & Vos
  # ResultFlag
  # ResultMessage
  # fval
  # exitflag
  # output
  # ----------------Inputs-------------------------------------
  #
  # ----------------Start code---------------------------------
  #
  # initialize variables
  ResultFlag <- 0
  nsL <- length(sL)
  # get endpoints of search interval
  mxspk <- max(sL)
  mnspk <- min(sL)
  
  # set upper end of search interval
  if( lcmrlval <= 0)   # idicates no valid LCMRL
  {
    xmx <- mxspk   # upper end of search interval
    if(ZRF)
    {
      xmn <- mnspk/10 # tenative lower end of search interval
    } else
    {
      xmn <- mnspk  # tenative lower end of serach interval
    }
  } else
  {
    xmx <- max(lcmrlval,mnspk) # upper end of serach interval
    if(ZRF)
    {
      xmn <- min(lcmrlval,mnspk) # tenative lower end of search interval
    } else
    {
      xmn <- min(lcmrlval,mnspk)/10 # tenative lower end of search interval
    }
  }
  # ensure that sign of EstFn is positive at lower end of interval
  if(ZRF == 0)
  {
    while( sign(DLEstFn(xmn,yc=yc,MFP=MFP,VFP=VFP,MSEFP=MSEFP,MV=MV,
                        b=b,RNNR=RNNR)) < 0 )
    {
      xmn <- xmn/2
    }
  } else
  {
    if( lcmrlval == mnspk || sign(DLEstFn(xmn,yc=yc,MFP=MFP,VFP=VFP,
                                          MSEFP=MSEFP,MV=MV,b=b,RNNR=RNNR)) < 0)
    {
      DLval <- min(sL)
      ResultFlag <- -4
      ResultMessage <- 'DL unreliable because of non-zero spiking levels with 0 results'
      return(list(DLval,fval <- NA,ResultFlag,ResultMessage))
    }
  }
  # ensure that sign of EstFn is negative at upper end of interval
  while(sign(DLEstFn(xmx,yc=yc,MFP=MFP,VFP=VFP,MSEFP=MSEFP,MV=MV,
                     b=b,RNNR=RNNR)) == 1 )
  {
    xmx <- 1.2*xmx
    if (xmx > mxspk)
    {
      ResultFlag <- -2
      ResultMessage <- 'PROBLEM: DL may be above max spiking level'
      return(list(DLval<-NA,fval <- NA,ResultFlag,ResultMessage))
    }
  }
  
  # find zero of EstFn; this is the HV DL
  DL.lst <- try( uniroot(DLEstFn,c(xmn,xmx),yc=yc,MFP=MFP,VFP=VFP,MSEFP=MSEFP,
                         MV=MV,b=b,RNNR=RNNR,lower = xmn, upper = xmx,
                         tol = 1e-6))
  if( class(DL.lst)=="try-error")
  {
    ResultFlag <- -3
    ResultMessage <- geterrmessage()
    return(list(DLval<- NA,fval<-NA,Resultflag,Resultmessage))
  }
  
  DLval <- DL.lst[[1]]
  fval <- DL.lst[[2]]
  # is DL < LCMRL
  if( DLval >= lcmrlval )
  {
    DLval <- lcmrlval
    ResultFlag <- 2
    ResultMessage <- 'DL calculated >= LCMRL; set DL = LCMRL';
  }
  if(ResultFlag == 0) # ResultFlag not set
  {
    ResultFlag <- 1
    ResultMessage <- 'DL Calculated'
  }
  return(list(DLval, fval, ResultFlag, ResultMessage))
}

#
# -------------------------End srchDL------------------------------
#######################################################################

#######################################################################
# -------------------------Start DLEstFn-----------------------------

DLEstFn <-function(xd,yc,MFP,VFP,MSEFP,MV,b,RNNR)
{
  # DLEstFn function
  #
  # Estimating function for difference between probability content of gamma
  # distribution between two limits and target coverage. Mean and variance
  # are specified by the independent variable x and with specified mean
  # and variance functions.
  #
  # ----------------Outputs-------------------------------------
  #
  # discrep = est'd difference between probability content of interval
  # and target coverage
  #
  # ----------------Inputs-------------------------------------
  #
  # xd = hypothetical spiking level
  #
  # ----------------Start code---------------------------------
  #
  
  discrep <- -Inf
  
  #   assign gamma parameter values
  lmm <- MeanFn(xd,MFP)
  lv <- VarFn(xd,MSEFP)
  if( RNNR == 1 && lmm > 0 )
  {
    M <- lmm + 10*sqrt(lv)
    if( lv <= lmm*(M-lmm) )
    {
      gpars <- GammaPars(lmm,lv)
      A <- gpars[[1]]
      B <- gpars[[2]]
      # compute coverage probability discrepancy
      discrep <- pgamma(yc,A,scale=B)-b
    } else
    {
      # to avoid problems with gamma prob, use truncated t
      DoF <- MSEFP$DoF
      f <- pt(-lmm/sqrt(lv),DoF)
      discrep <- (pt((yc-lmm)/sqrt(lv),DoF)- f)/(1-f) - b
    }
  } else
  {
    DoF <- MSEFP$DoF
    discrep <- pt((yc-lmm)/sqrt(lv),DoF) - b
  }
  return(discrep)
}

# -------------------------End DLEstFn-----------------------------
#######################################################################

####################################################################
# ---------------------Start Bayes.1.Boot ---------------------------------
Bayes.1.Boot <- function (xx, boot.iter,Seed)
  
  # computes Bayesian Bootstrap prior weights for Monte Carlo of LCMRL,
  # Lc and HV-DL,
  #
  # ----------------Outputs-------------------------------------
#
# wgt.mat = matrix of prior weights for spiking levels and measurement pairs
#
# ----------------Inputs-------------------------------------
#
# X = vector of spiked concentrations
# boot.iter = number of bootstrap replications
#
# ----------------Start code---------------------------------
#
{
  stab <- cbind(as.numeric(names(table(xx))),table(xx))
  sL <- stab[,1]     # spiking levels
  nsL <- length(sL)  # number of spiking levels
  nobs <- stab[,2]   # number of observations per spiking level
  
  W.mat <- matrix(0,boot.iter,length(xx))
  set.seed(Seed)
  W.mat <- apply(W.mat,2,rexp)
  wgt.mat <- W.mat
  W.pos <- 1
  for(i in 1:nsL)
  {
    wgt.mat[,W.pos:(W.pos+nobs[i]-1)]<- t(apply(W.mat[,W.pos:(W.pos+nobs[i]-1)],1,function(z) (length(z)*z/sum(z))))
    W.pos <- W.pos + nobs[i]
  }
  return(wgt.mat)
}
# -------------------------End Bayes.1.Boot------------------------------
####################################################################
####################################################################
# -------------------Start LCMRL.data.rand.pert--------------------------
# LCMRL.data.rand.pert -- function to generate random scale perturbation
# by spiking level of LCMRL data set
#
# model is y*_ij = b_i*y_ij
#
# random scale factor b_i is gamma with mean 1 and std dev r.scale.sd
# independent for each spiking level i

LCMRL.data.rand.pert<-function(spike,measured,r.scale.sd=0.03) {
  
  spk.lev<-unique(spike)
  n.lev<-length(spk.lev)
  n.reps<-as.vector(table(spike))
  
  b.s<-r.scale.sd^2
  a.s<-1/b.s
  r.scale<-rgamma(n.lev,shape=a.s,scale=b.s)
  r.sv<-rep(r.scale[1],n.reps[1])
  for(e in 2:n.lev) r.sv<-c(r.sv,rep(r.scale[e],n.reps[e]))
  
  return(measured*r.sv)
  
}
# -------------------End LCMRL.data.rand.pert----------------------------
####################################################################

#######################################################################
# -------------------------Start VarWghts------------------------------
Varwgts <- function(xSL,BW,RW)
  # This function c
  #
  # ----------------Inputs-------------------------------------
# xSL = column vector of Spiking concentrations
# BW = Bayesian Bootstrap Weights normalized weights from robust estmation
# RW = Robust Weights
#
# ----------------Outputs-------------------------------------
#
# VW = weights to be used for variance modeling
{
  stab <- cbind(as.numeric(names(table(xSL))),table(xSL))
  sL <- stab[,1]     # spiking levels
  nsL <- length(sL)  # number of spiking levels
  nobs <- stab[,2]   # number of observations per spiking level
  
  VW <- BW*RW
  tmp <- aggregate(VW,list(xSL),sum)
  #tot <- sum(tmp[,2])
  dof <- nobs-1
  #return(tmp[,2]*dof/tot)
  return(tmp[,2]*dof)
}
# ------------------------- End VarWghts------------------------------
#######################################################################

#######################################################################
# ------------------------- Start std.z------------------------------

std.z <- function(x,locvar)
  # This function standarizes a list of vector of values x to a list of vectors random variable with 0
  # mean and unit variance
  #  x = a list of numeric vectors containg the LCMRLs of the BB by lab
  #  locvar =  a matrix of lists with columns equal to length(x)
  #        first row being robust means of x from roblocvar4 for lab i
  #        second row being robust variances of x from roblocvar4 for lab i
{
  n <- length(x)
  std.res <- vector("list",n)
  for( i in 1:n)
  {
    diff <- x[[i]]-as.numeric(locvar[1,])[i]
    std.res[[i]] <- diff/sqrt(as.numeric(locvar[2,])[i])
  }
  return( std.res )
}
# ------------------------- End std.z------------------------------
#######################################################################

#######################################################################
# ------------------------- Start std2.z------------------------------
std2.z <- function(x,locvar)
  # This function standarizes a list of vector of values x to a list of vectors random variable with 0
  # mean and unit variance
  #  x = a list of numeric vectors containg the LCMRLs of the BB by lab
  #  locvar =  a matrix of lists with columns equal to length(x)
  #        first row being robust means of x from roblocvar4 for lab i
  #        second row being robust variances of x from roblocvar4 for lab i
{
  n <- length(x)
  std.res <- vector("numeric",n)
  
  # Log the entire input vector x for debugging ASG 9-30-25
  # write.csv(data.frame(Value = x), file = paste0("x_debug.csv"), row.names = FALSE)
  
  # Log locvar for debugging ASG 9-30-25
  # write.csv(as.data.frame(locvar), file = paste0("locvar_debug.csv"), row.names = FALSE)
  
  for( i in 1:n)
  {
    diff <- x[[i]]-locvar[1]
    
    # if (locvar[2] <= 0) { # Mitigation attempt ASG 9-30-25
    #  warning("Zero or negative variance detected, setting to small positive value") # Mitigation attempt ASG 9-30-25
    #  locvar[2] <- 1e-6  # Set a small positive value to avoid division by zero or NaN ASG 9-30-25
    #}
    std.res[i] <- diff/sqrt(locvar[2])
    
    # Log std.res for debugging ASG 9-30-25
    #write.table(data.frame(std.res), file = paste0("std_res_debug.csv"), row.names = FALSE, col.names = FALSE, append = TRUE, sep = ",")
  }
  return( std.res )
}
# ------------------------- End std2.z------------------------------
#######################################################################

#######################################################################
# ------------------------- Start guttman.utl ------------------------------

guttman.utl <- function(x,a=0.95,b=0.95)
  # This function returns the Guttman's non-parametric UTL of a vector x of
  # values for given UTL coverage of b and desired comfidence a. Both a and
  # b are in (0,1).
  # ----------------Inputs-------------------------------------
#
# x = numeric vector
# a = confidence coefficient in (0,1)
# b = required coverage in (0,1)
# ---------------Outputs-------------------------------------
#
# utl =  upper tolerance limit of desired coverage
#

{
  n <- length(x)
  p.est <- floor(b*n)
  k <- p.est:n
  pp <- vector("numeric",length(k))
  pp <- pbeta(1-b,n-k+1,k-1)
  dif <- abs(a-pp)
  kutl <- match(min(dif),dif)
  return(as.vector(sort(x)[k[kutl]]))
}
# ------------------------- End guttman.utl------------------------------
#######################################################################

#######################################################################
# ------------------------- Start wgt.guttman.utl ---------------------
wgt.guttman.utl <- function(x,y,a=0.95,b=0.95)
{
  #
  # This function returns a one sided upper Guttman's non-parametric UTL of
  # a vector x of values with associated weights y for given UTL coverage
  # of b and desired comfidence a. Both a and b are in (0,1).
  #
  # ----------------Inputs-------------------------------------
  #
  # x = numeric vector
  # y = a normalized vector of weights summing to 1 associated with each x
  # a = confidence coefficent
  # b = required coverage
  # ---------------Outputs-------------------------------------
  #
  # utl =  upper tolerance limit of desired coverage
  #
  
  if( (a<0 || a>1) || (b<0 || b>1) )
  {
    stop("Error in wgt.guttma.utl: a and b must be between 0 and 1")
  }
  xs <- sort(x,index=TRUE)
  x <- xs$x
  y <- y[xs$ix]
  csum.y <- cumsum(y)
  lenx <- length(x)
  # find guttman UTL of raw data
  r.utl <- guttman.utl(x,a,b)
  #find position of UTL in raw data
  flag <- x>=r.utl
  p2 <- match(TRUE,flag)
  p1 <- p2-1
  slp <- 1/(lenx+1)
  slp <- slp/(x[p2]-x[p1])
  cnst <- p2/(lenx+1) - slp*x[p2]
  r.utl.p <- slp*r.utl+cnst
  #find the postion r.utl.p in the weighted data
  flag <- csum.y >= r.utl.p
  p2 <- match(TRUE,flag)
  p1 <- p2-1
  slp <- 1/(csum.y[p2]-csum.y[p1])
  cnst <- p2-slp*csum.y[p2]
  w.utl.p <- slp*r.utl.p+cnst
  # find the LCMRL value at the weighted position w.utl.p
  p1 <- floor(w.utl.p)
  p2 <- p1+1
  slp <- (x[p2]-x[p1])
  cnst <- x[p2]-slp*p2
  utl <- slp*w.utl.p+cnst
  return(utl)
}
# ------------------------- End wgt.guttman.utl -----------------------
#######################################################################

#######################################################################
# ------------------------- Start wt.bw.1.sided ---------------------
wt.bw.1.sided<-function(x,rloc,rscale,cc=6,reltol=1e-6,maxsteps=100)
{
  # compute weights for one-sided Biweight(c)
  # M-estimate of location
  
  rlold <- rloc
  delta <- 1
  nsteps <- 0
  while(delta > reltol && nsteps <= maxsteps)
  {
    u <- ifelse(x>rloc,(x - rloc)/(cc*rscale),0)
    tu <- abs(u) <= 1
    rwtsBW <- ((1-u^2)^2) * tu
    rwtsBW <- rwtsBW/sum(rwtsBW)
    rloc <- sum(rwtsBW*x)
    delta <- try(abs((rl_old - rloc)/rl_old),silent=TRUE)
    if(class(delta)=="try-error" ) {delta <- 0 }
    nsteps <- nsteps +1
    rlold <- rloc
  }
  return(list(loc=rloc,weights=rwtsBW))
}
# ------------------------- End wt.bw.1.sided -------------------------
#######################################################################