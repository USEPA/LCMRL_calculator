#' Launch the LCMRL Shiny GUI
#'
#' This function launches a graphical interface for using the LCMRL package.
#' @export
run_LCMRL_GUI <- function() {
  appDir <- system.file("shiny_apps/LCMRL_app", package = "LCMRL")
  if (appDir == "") {
    stop("Could not find LCMRL app directory. Try reinstalling the package.", call. = FALSE)
  }
  shiny::runApp(appDir, display.mode = "normal", launch.browser = TRUE)
}

#' Launch the MRL Shiny GUI
#'
#' This function launches a graphical interface for using the MRL functionality in the LCMRL package.
#' @export
run_MRL_GUI <- function() {
  appDir <- system.file("shiny_apps/MRL_app", package = "LCMRL")
  if (appDir == "") {
    stop("Could not find MRL app directory. Try reinstalling the package.", call. = FALSE)
  }
  shiny::runApp(appDir, display.mode = "normal",launch.browser = TRUE)
}