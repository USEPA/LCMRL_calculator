.onLoad <- function(libname, pkgname) {
    # Automatically load necessary packages
    library(lattice)
    library(car)
    library(doParallel)
    library(rstudioapi)
    # 'foreach', 'iterators', and 'parallel' will be loaded automatically by 'doParallel'
}